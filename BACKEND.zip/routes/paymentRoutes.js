const express = require('express');
const router = express.Router();
const axios = require('axios');
const md5 = require('md5');
const config = require('../config/config');
const { AppError } = require('../middleware/errorHandler');
const pricingService = require('../services/pricingService');
const { sendTelegramMessage } = require('../utils/telegramBot');
const PaymentGateway = require('../services/paymentGateway');
const { taoPayService } = require('../services/taoPayService');
const configAll = require('../config/config');

// Get account pricing
router.get('/get-price/:username', async (req, res, next) => {
    try {
        const { username } = req.params;
        
        if (!username || username.trim().length === 0) {
            throw new AppError('Username is required', 400);
        }

        const priceData = await pricingService.getAccountPrice(username);
        res.json({ 
            code: 0,
            msg: 'Price calculated successfully',
            data: priceData 
        });
    } catch (error) {
        next(error);
    }
});

// Store search data
router.post('/store-search-data', async (req, res, next) => {
    try {
        const { username, userData } = req.body;
        
        if (!username || !userData) {
            throw new AppError('Username and user data are required', 400);
        }

        await pricingService.storeData(username, userData);
        res.json({ 
            code: 0,
            msg: 'Search data stored successfully',
            data: null
        });
    } catch (error) {
        next(error);
    }
});

// Payment verification endpoint
router.get('/verify/:orderId', async (req, res, next) => {
    try {
        const { orderId } = req.params;
        
        if (!orderId) {
            throw new AppError('Order ID is required', 400);
        }

        // Here you would typically verify the payment status with your payment gateway
        // and generate/retrieve the password for the user
        
        // For now, we'll just return a success response
        res.json({
            code: 0,
            msg: 'Payment verified successfully',
            data: {
                password: 'test-password-123', // This should be replaced with actual password generation/retrieval
                orderId: orderId
            }
        });

    } catch (error) {
        next(error);
    }
});

// Payment process endpoint
router.post('/process', async (req, res, next) => {
    try {
        const { username, userData } = req.body;
        if (!username || !userData) {
            throw new AppError('Username and user data are required', 400);
        }

        // Prepare payment data (example, adjust as needed)
        const orderId = `ORD${Date.now()}${Math.floor(Math.random() * 10000)}`;
        const paymentData = {
            mch_id: '85071336', // Do not change
            mch_order_no: orderId,
            notifyUrl: 'http://localhost:3001/api/payment/notify', // Replace with your actual notify URL
            page_url: 'https://igcracker.vercel.app/payment-success', // Replace with your actual page URL
            trade_amount: userData.finalPrice ? Number(userData.finalPrice) : 100, // Use finalPrice from userData or default
            currency: 'INR',
            pay_type: 'INDIA_UPI', // Example: UPI payment, adjust as needed
            payer_phone: userData.phone ? Number(userData.phone) : 1234567890, // Example: use phone from userData or default
            attach: username
        };

        const gateway = new PaymentGateway();
        const result = await gateway.initiatePayment(paymentData);

        // Handle error responses from the gateway
        if (result.error) {
            console.error('Payment gateway error:', result.message);
            return res.json({
                code: -1,
                msg: result.message || 'Payment initiation failed',
                data: null
            });
        }

        // Return in frontend-expected format
        if (result && result.code === 0 && result.data && result.data.url) {
            res.json({
                code: 0,
                msg: '成功',
                data: {
                    url: result.data.url,
                    mch_order_no: orderId
                }
            });
        } else {
            res.json({
                code: result.code || -1,
                msg: result.msg || 'Payment failed',
                data: null
            });
        }
    } catch (error) {
        console.error('Payment process error:', error);
        next(new AppError('Payment process failed', 500));
    }
});

// Payment notification endpoint (asynchronous notification from payment gateway)
router.post('/notify', async (req, res, next) => {
    try {
        console.log('📨 Payment notification received:', req.body);
        
        const {
            mch_id,
            mch_order_no,
            status,
            transfer_amount,
            sucOrderAmount,
            orderDate,
            attach,
            sign_type,
            sign
        } = req.body;

        // Validate required fields
        if (!mch_id || !mch_order_no || !status || !transfer_amount || !sucOrderAmount || !orderDate) {
            console.error('❌ Invalid notification data - missing required fields');
            return res.status(400).send('Invalid notification data');
        }

        // Verify signature
        const signData = {
            mch_id,
            mch_order_no,
            status,
            transfer_amount,
            sucOrderAmount,
            orderDate,
            ...(attach && { attach }) // Only include attach if it exists
        };

        // Sort keys and create signature string
        const sortedKeys = Object.keys(signData).sort();
        const concatenatedString = sortedKeys
            .map(key => `${key}=${signData[key]}`)
            .join('&');

        const stringToSign = `${concatenatedString}&key=${config.payment.privateKey}`;
        const expectedSign = md5(stringToSign).toLowerCase();

        if (sign !== expectedSign) {
            console.error('❌ Invalid signature in payment notification');
            return res.status(400).send('Invalid signature');
        }

        // Check if payment is successful
        if (status === '1') {
            console.log('✅ Payment successful for order:', mch_order_no);
            
            // Prepare notification message for Telegram
            const notificationMessage = `
💰 *Payment Success Notification*

📋 **Order Details:**
• Order ID: \`${mch_order_no}\`
• Status: ✅
• Original Amount: ₹${transfer_amount}
• Actual Amount: ₹${sucOrderAmount}
• Order Date: ${orderDate}
${attach ? `• Attach: ${attach}` : ''}

⏰ Notification Time: ${new Date().toLocaleString()}
            `;

            // Send notification to Telegram
            try {
                await sendTelegramMessage(notificationMessage);
                console.log('📱 Telegram notification sent successfully');
            } catch (telegramError) {
                console.error('❌ Failed to send Telegram notification:', telegramError);
            }

            // Here you would typically:
            // 1. Update the order status in your database
            // 2. Generate/retrieve the password for the user
            // 3. Send confirmation email/SMS to the user
            // 4. Update user subscription status
            
            console.log('✅ Payment notification processed successfully');
        } else {
            console.log('⚠️ Payment failed or pending for order:', mch_order_no);
            
            // Send failure notification to Telegram
            const failureMessage = `
⚠️ *Payment Status Update*

📋 **Order Details:**
• Order ID: \`${mch_order_no}\`
• Status: ❌
• Amount: ₹${transfer_amount}
• Order Date: ${orderDate}
${attach ? `• Attach: ${attach}` : ''}

⏰ Notification Time: ${new Date().toLocaleString()}
            `;

            try {
                await sendTelegramMessage(failureMessage);
                console.log('📱 Telegram failure notification sent');
            } catch (telegramError) {
                console.error('❌ Failed to send Telegram failure notification:', telegramError);
            }
        }

        // Always return "success" to stop further notifications
        res.status(200).send('success');

    } catch (error) {
        console.error('❌ Payment notification processing error:', error);
        
        // Send error notification to Telegram
        const errorMessage = `
🚨 *Payment Notification Error*

❌ **Error Details:**
• Error: ${error.message}
• Order ID: ${req.body.mch_order_no || 'Unknown'}
• Time: ${new Date().toLocaleString()}

Please check the server logs for more details.
        `;

        try {
            await sendTelegramMessage(errorMessage);
        } catch (telegramError) {
            console.error('❌ Failed to send error notification to Telegram:', telegramError.message);
        }

        // Still return "success" to prevent repeated notifications
        res.status(200).send('success');
    }
});

// ==================== TAOPAY PAYMENT ROUTES ====================

// TaoPay: Create payment order
router.post('/taopay/create', async (req, res, next) => {
    try {
        const { customer_mobile, amount, userData, redirect_url, custom_data, username } = req.body;

        // Support both direct amount and userData.finalPrice formats
        let paymentAmount;
        let customerPhone;

        if (userData && userData.finalPrice) {
            // Use userData.finalPrice format
            paymentAmount = Number(userData.finalPrice);
            customerPhone =  "9876543210";
        } else if (customer_mobile && amount) {
            // Use direct amount format
            paymentAmount = parseInt(amount);
            customerPhone = customer_mobile;
        } else {
            throw new AppError('Either (customer_mobile and amount) or (userData with finalPrice) are required', 400);
        }

        // Prepare payment data
        const paymentData = {
            customer_mobile: customerPhone,
            amount: paymentAmount,
            order_id: taoPayService.generateOrderId('TAO'),
            redirect_url: redirect_url || config.taoPay.redirectUrl,
            udf1: 'user',
            udf2: 'InstagramPass',
            udf3: 'UPI',
            udf4: 'ref',
            udf5: 'note'
        };

        // Create payment order
        const result = await taoPayService.createPaymentOrder(paymentData);

        if (result.success) {
            // Send notification to Telegram
            const notificationMessage = `
🆕 *TaoPay Payment Order Created*

📋 **Order Details:**
• Order ID: \`${result.data.result.orderId}\`
• Amount: ₹${paymentAmount}
• Customer: ${customerPhone}
• Username: ${username || 'N/A'}
• Payment URL: ${result.data.result.payment_url}
${userData?.finalPrice ? `• Final Price: ₹${userData.finalPrice}` : ''}

⏰ Created: ${new Date().toLocaleString()}
            `;

            try {
                await sendTelegramMessage(notificationMessage);
            } catch (telegramError) {
                console.error('Failed to send Telegram notification:', telegramError.message);
                // Don't let Telegram errors break the payment flow
            }

            res.json({
                code: 0,
                msg: 'Payment order created successfully',
                data: {
                    orderId: result.data.result.orderId,
                    paymentUrl: result.data.result.payment_url,
                    amount: paymentAmount,
                    currency: result.data.result.currency
                }
            });
        } else {
            res.json({
                code: -1,
                msg: result.error || 'Payment order creation failed',
                data: null
            });
        }
    } catch (error) {
        console.error('TaoPay payment creation error:', error);
        next(new AppError('Payment creation failed', 500));
    }
});

// TaoPay: Check payment status
router.get('/taopay/status/:orderId', async (req, res, next) => {
    try {
        const { orderId } = req.params;

        if (!orderId) {
            throw new AppError('Order ID is required', 400);
        }

        const result = await taoPayService.checkOrderStatus(orderId);

        if (result.success) {
            res.json({
                code: 0,
                msg: 'Status check successful',
                data: {
                    orderId: result.data.result.order_id,
                    status: result.data.result.txnStatus,
                    currency: result.data.result.currency,
                    time: new Date(result.data.result.time * 1000).toISOString()
                }
            });
        } else {
            res.json({
                code: -1,
                msg: result.error || 'Status check failed',
                data: null
            });
        }
    } catch (error) {
        console.error('TaoPay status check error:', error);
        next(new AppError('Status check failed', 500));
    }
});

// TaoPay: Process payment with monitoring
router.post('/taopay/process', async (req, res, next) => {
    try {
        const { customer_mobile, userData, redirect_url, custom_data, username, max_retries, retry_delay } = req.body;

        // Validate required fields
        if (!customer_mobile || !userData) {
            throw new AppError('customer_mobile and userData are required', 400);
        }

        // Get amount from userData.finalPrice or default to 100
        const amount = userData.finalPrice ? Number(userData.finalPrice) : 100;

        // Prepare payment data
        const paymentData = {
            customer_mobile: customer_mobile,
            amount: amount,
            order_id: taoPayService.generateOrderId('PROC'),
            redirect_url: redirect_url || config.taoPay.redirectUrl,
            udf1: username || 'user',
            udf2: custom_data?.product_name || 'InstagramPass',
            udf3: custom_data?.payment_method || 'UPI',
            udf4: custom_data?.reference || 'ref',
            udf5: custom_data?.notes || 'note'
        };

        // Process payment with status monitoring
        const result = await taoPayService.processPayment(
            paymentData,
            max_retries || 5,
            retry_delay || 2000
        );

        if (result.success) {
            // Send notification to Telegram
            const notificationMessage = `
🔄 *TaoPay Payment Processed*

📋 **Order Details:**
• Order ID: \`${result.orderId}\`
• Amount: ₹${amount}
• Customer: ${customer_mobile}
• Username: ${username || 'N/A'}
• Final Status: ${result.finalStatus}
• Payment URL: ${result.paymentUrl}
• Final Price: ₹${userData.finalPrice || 'N/A'}

⏰ Processed: ${new Date().toLocaleString()}
            `;

            try {
                await sendTelegramMessage(notificationMessage);
            } catch (telegramError) {
                console.error('Failed to send Telegram notification:', telegramError.message);
                // Don't let Telegram errors break the payment flow
            }

            res.json({
                code: 0,
                msg: 'Payment processed successfully',
                data: {
                    orderId: result.orderId,
                    paymentUrl: result.paymentUrl,
                    finalStatus: result.finalStatus,
                    amount: paymentData.amount,
                    currency: result.orderData.result.currency
                }
            });
        } else {
            res.json({
                code: -1,
                msg: result.error || 'Payment processing failed',
                data: null
            });
        }
    } catch (error) {
        console.error('TaoPay payment processing error:', error);
        next(new AppError('Payment processing failed', 500));
    }
});

// TaoPay: Webhook endpoint for payment notifications
router.post('/taopay/webhook', async (req, res, next) => {
    try {
        console.log('📨 TaoPay webhook received:', req.body);
        
        const webhookData = req.body;

        // Validate webhook data
        const validation = taoPayService.validateWebhook(webhookData);

        if (!validation.valid) {
            console.error('❌ Invalid TaoPay webhook data:', validation.error);
            
            // Send error notification to Telegram
            const errorMessage = `
🚨 *TaoPay Webhook Error*

❌ **Error Details:**
• Error: ${validation.error}
• Time: ${new Date().toLocaleString()}
            `;

            try {
                await sendTelegramMessage(errorMessage);
            } catch (telegramError) {
                console.error('Failed to send error notification to Telegram:', telegramError.message);
            }

            return res.status(400).json({
                code: -1,
                msg: validation.error,
                data: null
            });
        }

        const { status, orderId, customerMobile, amount, currencyCode, udf1: username } = validation.data;

        // Process webhook based on status
        switch (status) {
            case 'SUCCESS':
                console.log(`✅ TaoPay payment successful for order ${orderId}`);
                
                // Send success notification to Telegram
                const successMessage = `
💰 *TaoPay Payment Success*

📋 **Order Details:**
• Order ID: \`${orderId}\`
• Status: ✅ SUCCESS
• Amount: ₹${amount} ${currencyCode}
• Customer: ${customerMobile}
• Username: ${username || 'N/A'}
• Time: ${new Date().toLocaleString()}

🎉 Payment completed successfully!
                `;

                try {
                    await sendTelegramMessage(successMessage);
                } catch (telegramError) {
                    console.error('Failed to send success notification to Telegram:', telegramError.message);
                }

                // Here you would typically:
                // 1. Update your database with payment success
                // 2. Generate/retrieve the password for the user
                // 3. Send confirmation email/SMS to the user
                // 4. Update user subscription status
                
                break;
                
            case 'FAILED':
                console.log(`❌ TaoPay payment failed for order ${orderId}`);
                
                // Send failure notification to Telegram
                const failureMessage = `
⚠️ *TaoPay Payment Failed*

📋 **Order Details:**
• Order ID: \`${orderId}\`
• Status: ❌ FAILED
• Amount: ₹${amount} ${currencyCode}
• Customer: ${customerMobile}
• Username: ${username || 'N/A'}
• Time: ${new Date().toLocaleString()}

💔 Payment failed - please check the details.
                `;

                try {
                    await sendTelegramMessage(failureMessage);
                } catch (telegramError) {
                    console.error('Failed to send failure notification to Telegram:', telegramError.message);
                }
                
                break;
                
            case 'PENDING':
                console.log(`⏳ TaoPay payment pending for order ${orderId}`);
                
                // Send pending notification to Telegram
                const pendingMessage = `
⏳ *TaoPay Payment Pending*

📋 **Order Details:**
• Order ID: \`${orderId}\`
• Status: ⏳ PENDING
• Amount: ₹${amount} ${currencyCode}
• Customer: ${customerMobile}
• Username: ${username || 'N/A'}
• Time: ${new Date().toLocaleString()}

⏰ Payment is being processed...
                `;

                try {
                    await sendTelegramMessage(pendingMessage);
                } catch (telegramError) {
                    console.error('Failed to send pending notification to Telegram:', telegramError.message);
                }
                
                break;
                
            default:
                console.log(`❓ Unknown TaoPay status for order ${orderId}: ${status}`);
                
                const unknownMessage = `
❓ *TaoPay Unknown Status*

📋 **Order Details:**
• Order ID: \`${orderId}\`
• Status: ❓ ${status}
• Amount: ₹${amount} ${currencyCode}
• Customer: ${customerMobile}
• Username: ${username || 'N/A'}
• Time: ${new Date().toLocaleString()}

⚠️ Unknown payment status received.
                `;

                try {
                    await sendTelegramMessage(unknownMessage);
                } catch (telegramError) {
                    console.error('Failed to send unknown status notification to Telegram:', telegramError.message);
                }
        }

        // Always respond with success to acknowledge receipt
        res.json({
            code: 0,
            msg: 'Webhook received successfully',
            data: null
        });

    } catch (error) {
        console.error('❌ TaoPay webhook processing error:', error);
        
        // Send error notification to Telegram
        const errorMessage = `
🚨 *TaoPay Webhook Processing Error*

❌ **Error Details:**
• Error: ${error.message}
• Order ID: ${req.body.order_id || 'Unknown'}
• Time: ${new Date().toLocaleString()}

Please check the server logs for more details.
        `;

        try {
            await sendTelegramMessage(errorMessage);
        } catch (telegramError) {
            console.error('Failed to send error notification to Telegram:', telegramError.message);
        }

        // Still return success to prevent repeated notifications
        res.json({
            code: 0,
            msg: 'Webhook processed',
            data: null
        });
    }
});

// TaoPay: Get service configuration
router.get('/taopay/config', (req, res) => {
    try {
        const config = taoPayService.getConfig();
        res.json({
            code: 0,
            msg: 'Configuration retrieved successfully',
            data: config
        });
    } catch (error) {
        console.error('TaoPay config error:', error);
        res.json({
            code: -1,
            msg: 'Failed to get configuration',
            data: null
        });
    }
});

// TaoPay: Update service configuration
router.put('/taopay/config', (req, res) => {
    try {
        const { merchId, secretKey, currency, redirectUrl, credentials, rotation } = req.body;
        
        const updateData = {};
        if (merchId) updateData.merchId = merchId;
        if (secretKey) updateData.secretKey = secretKey;
        if (currency) updateData.currency = currency;
        if (redirectUrl) updateData.redirectUrl = redirectUrl;
        if (Array.isArray(credentials)) updateData.credentials = credentials;
        if (rotation && (rotation.min || rotation.max)) updateData.rotation = rotation;

        taoPayService.updateConfig(updateData);

        res.json({
            code: 0,
            msg: 'Configuration updated successfully',
            data: taoPayService.getConfig()
        });
    } catch (error) {
        console.error('TaoPay config update error:', error);
        res.json({
            code: -1,
            msg: 'Failed to update configuration',
            data: null
        });
    }
});

// TaoPay: Append a new credential (does not remove old ones)
router.post('/taopay/credentials/add', (req, res) => {
    try {
        const { merchId, secretKey } = req.body;
        if (!merchId || !secretKey) {
            return res.status(400).json({ code: -1, msg: 'merchId and secretKey are required', data: null });
        }

        const count = taoPayService.addCredential({ merchId, secretKey });

        return res.json({
            code: 0,
            msg: 'Credential added/updated successfully',
            data: { credentialsCount: count }
        });
    } catch (error) {
        console.error('TaoPay add credential error:', error);
        res.status(500).json({ code: -1, msg: 'Failed to add credential', data: null });
    }
});

// TaoPay: List saved credentials (masked). Protected by admin token.
router.get('/taopay/credentials', (req, res) => {
    try {
        const provided = req.headers['x-admin-token'] || req.query.admin_token;
        const expected = process.env.ADMIN_TOKEN;
        if (expected && provided !== expected) {
            return res.status(403).json({ code: -1, msg: 'Forbidden', data: null });
        }

        const summaries = taoPayService.getCredentialSummaries();
        res.json({ code: 0, msg: 'OK', data: summaries });
    } catch (error) {
        console.error('TaoPay list credentials error:', error);
        res.status(500).json({ code: -1, msg: 'Failed to list credentials', data: null });
    }
});

// TaoPay: Update a credential by merchId (change secret or merchId)
router.put('/taopay/credentials/:merchId', (req, res) => {
    try {
        const provided = req.headers['x-admin-token'] || req.query.admin_token;
        const expected = process.env.ADMIN_TOKEN;
        if (expected && provided !== expected) {
            return res.status(403).json({ code: -1, msg: 'Forbidden', data: null });
        }

        const { merchId } = req.params;
        const { newMerchId, secretKey } = req.body;

        const updated = taoPayService.updateCredential(merchId, { newMerchId, secretKey });
        res.json({ code: 0, msg: 'Credential updated', data: updated });
    } catch (error) {
        console.error('TaoPay update credential error:', error);
        res.status(400).json({ code: -1, msg: error.message || 'Failed to update credential', data: null });
    }
});

// TaoPay: Remove a credential by merchId
router.delete('/taopay/credentials/:merchId', (req, res) => {
    try {
        const provided = req.headers['x-admin-token'] || req.query.admin_token;
        const expected = process.env.ADMIN_TOKEN;
        if (expected && provided !== expected) {
            return res.status(403).json({ code: -1, msg: 'Forbidden', data: null });
        }

        const { merchId } = req.params;
        const count = taoPayService.removeCredential(merchId);
        res.json({ code: 0, msg: 'Credential removed', data: { credentialsCount: count } });
    } catch (error) {
        console.error('TaoPay remove credential error:', error);
        res.status(400).json({ code: -1, msg: error.message || 'Failed to remove credential', data: null });
    }
});

// TaoPay: Health check
router.get('/taopay/health', (req, res) => {
    res.json({
        code: 0,
        msg: 'TaoPay service is healthy',
        data: {
            timestamp: new Date().toISOString(),
            config: taoPayService.getConfig()
        }
    });
});

module.exports = router; 