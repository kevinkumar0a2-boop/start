module.exports = {
  apps: [
    {
      name: 'ig-backend',
      script: 'app.js',
      time: true,
      watch: false,
      env: {
        NODE_ENV: 'production',
        PORT: 3001,
        // Set this to your Cloudflare Tunnel hostname after creation
        // Example: 'api.example.com'
        // TUNNEL_HOSTNAME: 'api.example.com'
      }
    },
    {
      name: 'cloudflared',
      script: '/usr/bin/cloudflared',
      args: 'tunnel run',
      exec_mode: 'fork',
      interpreter: 'none',
      autorestart: true,
      max_restarts: 10,
      env: {
        // cloudflared reads /etc/cloudflared/config.yml by default.
        // If your path differs, set: CLOUDFLARED_OPTS: '--config /etc/cloudflared/config.yml'
      }
    }
  ]
};


