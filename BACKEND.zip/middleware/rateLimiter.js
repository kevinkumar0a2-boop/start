const rateLimit = require('express-rate-limit');
const config = require('../config/config');

// Optimized rate limiter with better performance
const apiLimiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.maxRequests,
  message: {
    code: -1,
    msg: 'Too many requests from this IP, please try again later.',
    data: null
  },
  standardHeaders: true,
  legacyHeaders: false,
  // Performance optimizations
  skipSuccessfulRequests: false,
  skipFailedRequests: false,
  keyGenerator: (req) => {
    // Use IP + user agent for better rate limiting
    return req.ip + ':' + (req.headers['user-agent'] || 'unknown');
  },
  handler: (req, res) => {
    res.status(429).json({
      code: -1,
      msg: 'Too many requests from this IP, please try again later.',
      data: null
    });
  },
  // Memory optimization
  store: undefined, // Use default in-memory store
  // Skip certain requests
  skip: (req) => {
    // Skip health checks and static files
    return req.path === '/health' || req.path.startsWith('/public/');
  }
});

// Strict limiter for sensitive operations
const strictLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10, // Increased from 5
  message: {
    code: -1,
    msg: 'Too many requests, please try again later.',
    data: null
  },
  keyGenerator: (req) => {
    return req.ip + ':' + (req.headers['user-agent'] || 'unknown');
  },
  skip: (req) => {
    return req.path === '/health';
  }
});

// Fast limiter for high-frequency endpoints
const fastLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 200, // Higher limit for fast endpoints
  message: {
    code: -1,
    msg: 'Rate limit exceeded, please slow down.',
    data: null
  },
  keyGenerator: (req) => req.ip,
  skip: (req) => req.path === '/health'
});

// Profile-specific limiter
const profileLimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 50, // Allow more profile requests
  message: {
    code: -1,
    msg: 'Too many profile requests, please try again later.',
    data: null
  },
  keyGenerator: (req) => req.ip,
  skip: (req) => req.path === '/health'
});

module.exports = {
  apiLimiter,
  strictLimiter,
  fastLimiter,
  profileLimiter
}; 