#!/usr/bin/env bash
set -euo pipefail

# Configuration (can be overridden via env)
APP_NAME="${APP_NAME:-ig-backend}"
APP_DIR="${APP_DIR:-/home/ubuntu/BACKEND}"
PORT="${PORT:-3001}"
TUNNEL_HOSTNAME="${TUNNEL_HOSTNAME:-}"
# Use Quick Tunnel only (ephemeral). Enabled by default.
QUICK_TUNNEL="${QUICK_TUNNEL:-1}"

echo "==> Preparing system (Ubuntu/Debian assumed)"
sudo apt update && sudo apt -y upgrade

if ! command -v node >/dev/null 2>&1; then
  echo "==> Installing Node.js 20.x"
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs build-essential
fi

if ! command -v pm2 >/dev/null 2>&1; then
  echo "==> Installing PM2"
  sudo npm i -g pm2
fi

echo "==> Creating app directory at ${APP_DIR}"
sudo mkdir -p "${APP_DIR}"
sudo chown "$USER:$USER" "${APP_DIR}"
cd "${APP_DIR}"

if [ -f package.json ]; then
  echo "==> Installing dependencies"
  npm install
else
  echo "!! package.json not found in ${APP_DIR}. Place the project files here and rerun."
  exit 1
fi

echo "==> Installing Playwright Chromium and dependencies"
sudo npx --yes playwright install --with-deps chromium || true

# Cloudflared installation via npm (global)
if ! command -v cloudflared >/dev/null 2>&1; then
  echo "==> Installing cloudflared via npm (global)"
  sudo npm i -g cloudflared
fi

# Resolve cloudflared binary path
CLOUDFLARED_BIN="$(command -v cloudflared || true)"
if [ -z "${CLOUDFLARED_BIN}" ]; then
  echo "!! cloudflared binary not found on PATH after npm install"
  exit 1
fi

# Ignore named tunnel hostnames; Quick Tunnel will be used exclusively
if [ -n "${TUNNEL_HOSTNAME}" ]; then
  echo "==> TUNNEL_HOSTNAME provided (${TUNNEL_HOSTNAME}) but will be ignored (Quick Tunnel only mode)"
fi

echo "==> Starting application with PM2 (ecosystem if present)"
if [ -f ecosystem.config.js ]; then
  # Ensure PORT and optional TUNNEL_HOSTNAME are passed to the app
  sudo env PORT="${PORT}" pm2 start ecosystem.config.js --only ig-backend || sudo env PORT="${PORT}" pm2 restart ig-backend --update-env
  if [ -n "${TUNNEL_HOSTNAME}" ]; then
    sudo env TUNNEL_HOSTNAME="${TUNNEL_HOSTNAME}" pm2 restart ig-backend --update-env || true
  fi
  # Do not start named cloudflared process; Quick Tunnel only
else
  if [ ! -f app.js ]; then
    echo "!! app.js not found in ${APP_DIR}. Ensure your project files are present."
    exit 1
  fi
  sudo env PORT="${PORT}" pm2 start app.js --name "${APP_NAME}" --time --update-env || sudo pm2 restart "${APP_NAME}" --update-env
fi

# If no named tunnel is configured and QUICK_TUNNEL is set, run a temporary Quick Tunnel
if [ -z "${TUNNEL_HOSTNAME}" ] && [ -n "${QUICK_TUNNEL}" ]; then
  echo "==> Starting Cloudflare Quick Tunnel (ephemeral) to http://localhost:${PORT}"
  if sudo pm2 describe quick-tunnel >/dev/null 2>&1; then
    sudo pm2 restart quick-tunnel --update-env || true
  else
    sudo pm2 start "${CLOUDFLARED_BIN}" --name quick-tunnel -- tunnel --no-autoupdate --url "http://localhost:${PORT}"
  fi
  echo "==> Quick Tunnel started. The public URL will appear in: sudo pm2 logs quick-tunnel --lines 50 | cat"

  # Try to detect the public URL from PM2 logs and propagate to app env and .env
  LOG_DIR="/root/.pm2/logs"
  LOG_FILE="${LOG_DIR}/quick-tunnel-out.log"
  echo "==> Waiting for Quick Tunnel URL in ${LOG_FILE}"
  QUICK_URL=""
  for _i in $(seq 1 60); do
    if [ -f "${LOG_FILE}" ]; then
      QUICK_URL=$(grep -oE 'https://[A-Za-z0-9.-]+\.trycloudflare\.com' "${LOG_FILE}" | tail -n 1 || true)
      if [ -n "${QUICK_URL}" ]; then
        break
      fi
    fi
    sleep 1
  done

  if [ -n "${QUICK_URL}" ]; then
    QUICK_HOST="${QUICK_URL#https://}"
    echo "==> Detected Quick Tunnel URL: ${QUICK_URL}"
    # Persist to .env for next restarts
    if [ -w ".env" ] || [ ! -f ".env" ]; then
      sudo touch .env || true
      sudo sed -i '/^BASE_URL=/d' .env || true
      sudo sed -i '/^TUNNEL_HOSTNAME=/d' .env || true
      sudo sed -i '/^CF_TUNNEL_HOSTNAME=/d' .env || true
      echo "BASE_URL=${QUICK_URL}" | sudo tee -a .env >/dev/null
      echo "TUNNEL_HOSTNAME=${QUICK_HOST}" | sudo tee -a .env >/dev/null
      echo "CF_TUNNEL_HOSTNAME=${QUICK_HOST}" | sudo tee -a .env >/dev/null
    fi
    # Restart app with updated env so config picks it up immediately
    sudo env BASE_URL="${QUICK_URL}" TUNNEL_HOSTNAME="${QUICK_HOST}" CF_TUNNEL_HOSTNAME="${QUICK_HOST}" pm2 restart ig-backend --update-env || true
  else
    echo "!! Could not detect Quick Tunnel URL within timeout"
  fi
fi

echo "==> Enabling PM2 startup on boot"
USER_NAME="$(whoami)"
USER_HOME="$(eval echo ~${USER_NAME})"
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u "${USER_NAME}" --hp "${USER_HOME}"
sudo pm2 save

echo "==> Done"
sudo pm2 status | cat

# All done. Show PM2 status
sudo pm2 status | cat