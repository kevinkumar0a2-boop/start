// Telegram Bot Configuration
// To set up Telegram bot notifications:
// 1. Create a bot with @BotFather on Telegram
// 2. Get your bot token and set TELEGRAM_BOT_TOKEN environment variable
// 3. Start a chat with your bot and get your chat ID
// 4. Set TELEGRAM_CHAT_ID environment variable with your chat ID
// 5. Or create a .env file with these variables

const config = require('./config');

module.exports = {
    BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || config.telegram.BOT_TOKEN,
    CHAT_ID: process.env.TELEGRAM_CHAT_ID || config.telegram.chatId
}; 