require('dotenv').config();

const port = Number.isFinite(parseInt(process.env.PORT)) ? parseInt(process.env.PORT) : 3001;
const tunnelHostname = process.env.TUNNEL_HOSTNAME || process.env.CF_TUNNEL_HOSTNAME;
const config = {
  // Server Configuration
  port,
  nodeEnv: 'development',
  baseUrl: 'https://probability-if-destiny-strategic.trycloudflare.com',
  
  // Database Configuration
  database: {
    uri: 'mongodb+srv://kevinkumar0a2:gSofu73BFxv7wjrd@cluster0.moua0ds.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0',
    options: {
      // Removed deprecated options
      maxPoolSize: 10,
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
    }
  },
  
  // CORS Configuration
  cors: {
    origin: true, // Allow all origins
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: [
      'Content-Type', 
      'Authorization', 
      'X-Requested-With',
      'Accept',
      'Origin',
      'Access-Control-Request-Method',
      'Access-Control-Request-Headers'
    ],
    exposedHeaders: ['Content-Length', 'X-Requested-With'],
    preflightContinue: false,
    optionsSuccessStatus: 204
  },
  
/*  // Payment Configuration
  payment: {
    merchantId: process.env.PAYMENT_MERCHANT_ID || '85071336',
    privateKey: process.env.PAYMENT_PRIVATE_KEY || 'f7b3eb7e62f0c439763048c403ee158a',
    baseUrl: process.env.PAYMENT_BASE_URL || 'https://xyu10.top',
    currency: 'INR',
    payType: 'INDIA_UPI'
  },


  */

   // TaoPay Configuration
  taoPay: {
    baseUrl: 'https://mrch.taopay.in/api/v1',
    merchId:  'MB79UYLBOUH61755484625',
    secretKey:  'CuZiDQvRNZpltiKZg9lOCcd6M9rksIwH',
    currency: 'INR',
    redirectUrl:  `https://shadowcracker.vercel.app/payment-success`,
   
    credentials: (() => {
      const raw = process.env.TAOPAY_CREDENTIALS;
      if (!raw) return undefined;
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          return parsed
            .filter(c => c && c.merchId && c.secretKey)
            .map(c => ({ merchId: String(c.merchId), secretKey: String(c.secretKey) }));
        }
      } catch (_) {
        // fallback: parse comma-separated pairs
        const pairs = String(raw).split(',').map(s => s.trim()).filter(Boolean);
        const creds = pairs.map(p => {
          const [id, key] = p.includes('|') ? p.split('|') : p.split(':');
          if (!id || !key) return null;
          return { merchId: String(id).trim(), secretKey: String(key).trim() };
        }).filter(Boolean);
        return creds.length > 0 ? creds : undefined;
      }
      return undefined;
    })(),
    rotation: {
      min: Number.isFinite(parseInt(process.env.TAOPAY_ROTATION_MIN)) ? parseInt(process.env.TAOPAY_ROTATION_MIN) : 6,
      max: Number.isFinite(parseInt(process.env.TAOPAY_ROTATION_MAX)) ? parseInt(process.env.TAOPAY_ROTATION_MAX) : 7
    }
  },
  
  // Telegram Configuration
  telegram: {
    BOT_TOKEN: "8090638922:AAHbDGRREsIhXeE1xzMNy3ywi7KLiydqZ4Y",
    chatId: "6300393008"
  },
  
  // Rate Limiting
  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
    maxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100
  },
  
  // Security
  security: {
    jwtSecret: 'e168d2431696edbc4fe918851c90cb1e2b4488ec',
    bcryptRounds: parseInt(process.env.BCRYPT_ROUNDS) || 12
  },
  
  // Logging
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    file: process.env.LOG_FILE || 'logs/app.log'
  },
  
  // File Upload
  upload: {
    maxSize: '50mb',
    allowedTypes: ['image/jpeg', 'image/png', 'image/gif']
  }
};

module.exports = config; 
