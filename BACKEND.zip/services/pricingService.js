const profileService = require('./profileService');
const requestManager = require('./requestManager');
const User = require('../models/User');

/**
 * Pricing Service for Instagram Account Valuation
 * Calculates account value based on followers, engagement, verification status, and other metrics
 */
class PricingService {
    constructor() {
        this.STORAGE_DURATION = 30 * 60 * 1000; // 30 minutes
        this.MIN_PRICE = 120;
        this.MAX_PRICE = 50000;
        
        // Pricing tiers based on follower count
        this.PRICING_TIERS = {
            TIER_1: { min: 1000000, price: 10000, name: '1M+ Followers' },
            TIER_2: { min: 500000, price: 8000, name: '500K+ Followers' },
            TIER_3: { min: 100000, price: 6000, name: '100K+ Followers' },
            TIER_4: { min: 50000, price: 4000, name: '50K+ Followers' },
            TIER_5: { min: 10000, price: 2000, name: '10K+ Followers' },
            TIER_6: { min: 5000, price: 1000, name: '5K+ Followers' },
            TIER_7: { min: 2000, price: 500, name: '2K+ Followers' },
            TIER_8: { min: 0, price: 199, name: 'Below 2K Followers' }
        };
        
        // Multipliers for different account features
        this.MULTIPLIERS = {
            VERIFIED: 1.5,
            BUSINESS: 1.2,
            PROFESSIONAL: 1.1,
            HIGHLIGHTS: 1.05,
            ENGAGEMENT_MIN: 0.8,
            ENGAGEMENT_MAX: 1.2
        };
    }

    /**
     * Validate username input
     * @param {string} username - Instagram username
     * @returns {boolean} - True if valid
     */
    validateUsername(username) {
        if (!username || typeof username !== 'string') {
            throw new Error('Username is required and must be a string');
        }
        
        const cleanUsername = username.trim().toLowerCase();
        if (cleanUsername.length < 1 || cleanUsername.length > 30) {
            throw new Error('Username must be between 1 and 30 characters');
        }
        
        if (!/^[a-zA-Z0-9._]+$/.test(cleanUsername)) {
            throw new Error('Username contains invalid characters');
        }
        
        return cleanUsername;
    }

    /**
     * Validate user data structure
     * @param {Object} userData - User profile data
     * @returns {Object} - Validated user data
     */
    validateUserData(userData) {
        if (!userData || typeof userData !== 'object') {
            throw new Error('Invalid user data provided');
        }

        const requiredFields = ['username', 'follower_count'];
        for (const field of requiredFields) {
            if (!userData.hasOwnProperty(field)) {
                throw new Error(`Missing required field: ${field}`);
            }
        }

        return {
            username: userData.username,
            follower_count: parseInt(userData.follower_count) || 0,
            following_count: parseInt(userData.following_count) || 0,
            media_count: parseInt(userData.media_count) || 0,
            is_verified: Boolean(userData.is_verified),
            is_business: Boolean(userData.is_business),
            is_professional: Boolean(userData.is_professional),
            has_highlight_reels: Boolean(userData.has_highlight_reels),
            highlight_reel_count: parseInt(userData.highlight_reel_count) || 0,
            engagement_rate: parseFloat(userData.engagement_rate) || 0
        };
    }

    /**
     * Get stored pricing data from database
     * @param {string} username - Instagram username
     * @returns {Object|null} - Stored data or null
     */
    async getStoredData(username) {
        try {
            const cleanUsername = this.validateUsername(username);
            const user = await User.findOne({ username: cleanUsername });
            
            if (user?.searchData?.pricingData) {
                const lastUpdated = new Date(user.searchData.lastUpdated);
                const isExpired = Date.now() - lastUpdated.getTime() > this.STORAGE_DURATION;
                
                if (!isExpired) {
                    return {
                        success: true,
                        data: user.searchData.profileData,
                        pricingData: user.searchData.pricingData,
                        cached: true,
                        lastUpdated: lastUpdated
                    };
                }
            }
            
            return null;
        } catch (error) {
            console.error('[Pricing] Error getting stored data:', error.message);
            return null;
        }
    }

    /**
     * Store profile and pricing data in database
     * @param {string} username - Instagram username
     * @param {Object} data - Profile data
     * @returns {Object} - Calculated pricing data
     */
    async storeData(username, data) {
        try {
            const cleanUsername = this.validateUsername(username);
            const userData = this.extractUserData(data);
            const validatedData = this.validateUserData(userData);
            const pricingData = this.calculateAccountValue(validatedData);
            
            const combinedData = {
                profileData: validatedData,
                pricingData: pricingData,
                lastUpdated: new Date()
            };

            let user = await User.findOne({ username: cleanUsername });
            
            if (!user) {
                user = new User({
                    username: cleanUsername,
                    email: `${cleanUsername}@example.com`,
                    password: 'temp',
                    searchData: combinedData
                });
            } else {
                user.searchData = combinedData;
            }
            
            await user.save();
            return pricingData;
            
        } catch (error) {
            console.error('[Pricing] Error storing data:', error.message);
            throw new Error(`Failed to store pricing data: ${error.message}`);
        }
    }

    /**
     * Extract user data from various response formats
     * @param {Object} data - Raw response data
     * @returns {Object} - Extracted user data
     */
    extractUserData(data) {
        if (!data) {
            throw new Error('No data provided');
        }

        // Handle new format: { result: [{ user: ... }] }
        if (data.result && Array.isArray(data.result) && data.result[0]?.user) {
            return data.result[0].user;
        }

        // Handle old format: { user: ... }
        if (data.user) {
            return data.user;
        }

        // Handle direct user data
        if (data.username && data.follower_count !== undefined) {
            return data;
        }

        throw new Error('Invalid data format: unable to extract user information');
    }

    /**
     * Calculate engagement rate based on available metrics
     * @param {Object} userData - Validated user data
     * @returns {number} - Engagement rate percentage
     */
    calculateEngagementRate(userData) {
        const { follower_count, following_count, media_count, engagement_rate } = userData;
        
        // If engagement rate is already provided, use it
        if (engagement_rate > 0) {
            return Math.min(engagement_rate, 100);
        }
        
        // Calculate based on following/follower ratio
        if (follower_count > 0 && following_count > 0) {
            const ratio = (following_count / follower_count) * 100;
            return Math.min(ratio, 100);
        }
        
        // Default engagement rate based on follower count
        if (follower_count >= 100000) return 2.5;
        if (follower_count >= 50000) return 3.0;
        if (follower_count >= 10000) return 3.5;
        if (follower_count >= 5000) return 4.0;
        if (follower_count >= 2000) return 4.5;
        
        return 5.0; // Default for small accounts
    }

    /**
     * Calculate base price based on follower count
     * @param {number} followerCount - Number of followers
     * @returns {Object} - Base price and tier information
     */
    calculateBasePrice(followerCount) {
        const tiers = Object.values(this.PRICING_TIERS);
        
        for (const tier of tiers) {
            if (followerCount >= tier.min) {
                return {
                    price: tier.price,
                    tier: tier.name,
                    followerCount
                };
            }
        }
        
        // Fallback to minimum tier
        return {
            price: this.PRICING_TIERS.TIER_8.price,
            tier: this.PRICING_TIERS.TIER_8.name,
            followerCount
        };
    }

    /**
     * Calculate account value with all multipliers
     * @param {Object} userData - Validated user data
     * @returns {Object} - Complete pricing breakdown
     */
    calculateAccountValue(userData) {
        try {
            const validatedData = this.validateUserData(userData);
            const { follower_count, is_verified, is_business, is_professional, has_highlight_reels, highlight_reel_count } = validatedData;
            
            // Calculate base price
            const basePriceInfo = this.calculateBasePrice(follower_count);
            let basePrice = basePriceInfo.price;
            
            // Calculate engagement rate
            const engagementRate = this.calculateEngagementRate(validatedData);
            
            // Apply multipliers
            let finalMultiplier = 1;
            const appliedMultipliers = {};
            
            // Verification multiplier
            if (is_verified) {
                finalMultiplier *= this.MULTIPLIERS.VERIFIED;
                appliedMultipliers.verified = this.MULTIPLIERS.VERIFIED;
            }
            
            // Business account multiplier
            if (is_business) {
                finalMultiplier *= this.MULTIPLIERS.BUSINESS;
                appliedMultipliers.business = this.MULTIPLIERS.BUSINESS;
            }
            
            // Professional account multiplier
            if (is_professional) {
                finalMultiplier *= this.MULTIPLIERS.PROFESSIONAL;
                appliedMultipliers.professional = this.MULTIPLIERS.PROFESSIONAL;
            }
            
            // Engagement rate multiplier
            const engagementMultiplier = this.MULTIPLIERS.ENGAGEMENT_MIN + 
                (engagementRate / 100) * (this.MULTIPLIERS.ENGAGEMENT_MAX - this.MULTIPLIERS.ENGAGEMENT_MIN);
            finalMultiplier *= engagementMultiplier;
            appliedMultipliers.engagement = engagementMultiplier;
            
            // Highlights multiplier
            const hasHighlights = has_highlight_reels || highlight_reel_count > 0;
            if (hasHighlights) {
                finalMultiplier *= this.MULTIPLIERS.HIGHLIGHTS;
                appliedMultipliers.highlights = this.MULTIPLIERS.HIGHLIGHTS;
            }
            
            // Calculate final price
            let finalPrice = Math.round(basePrice * finalMultiplier);
            
            // Apply price constraints
            if (finalPrice < this.MIN_PRICE) {
                finalPrice = this.MIN_PRICE;
            } else if (finalPrice > this.MAX_PRICE) {
                finalPrice = this.MAX_PRICE;
            }
            
            return {
                basePrice,
                finalPrice: finalPrice.toString(),
                tier: basePriceInfo.tier,
                multipliers: {
                    total: parseFloat(finalMultiplier.toFixed(2)),
                    breakdown: appliedMultipliers,
                    isVerified: is_verified,
                    isBusiness: is_business,
                    isProfessional: is_professional,
                    engagementRate: parseFloat(engagementRate.toFixed(2)),
                    hasHighlights: hasHighlights
                },
                metadata: {
                    followerCount: follower_count,
                    calculationDate: new Date().toISOString(),
                    version: '2.0'
                }
            };
            
        } catch (error) {
            console.error('[Pricing] Error calculating account value:', error.message);
            throw new Error(`Pricing calculation failed: ${error.message}`);
        }
    }

    /**
     * Get account price with caching and fallback
     * @param {string} username - Instagram username
     * @returns {Object} - Pricing data
     */
    async getAccountPrice(username) {
        try {
            const cleanUsername = this.validateUsername(username);
            
            // Check stored data first
            const storedData = await this.getStoredData(cleanUsername);
            if (storedData?.pricingData) {
                return {
                    ...storedData.pricingData,
                    cached: true,
                    lastUpdated: storedData.lastUpdated
                };
            }
            
            // Fetch fresh profile data
            const profileData = await profileService.getProfileData(cleanUsername);
            const userData = this.extractUserData(profileData);
            
            // Calculate and store pricing data
            const pricingData = await this.storeData(cleanUsername, profileData);
            
            return {
                ...pricingData,
                cached: false,
                lastUpdated: new Date()
            };
            
        } catch (error) {
            console.error('[Pricing] Error calculating account price:', error.message);
            throw new Error(`Failed to calculate account price: ${error.message}`);
        }
    }

    /**
     * Clear cached pricing data for a username
     * @param {string} username - Instagram username
     * @returns {boolean} - Success status
     */
    async clearCachedData(username) {
        try {
            const cleanUsername = this.validateUsername(username);
            const user = await User.findOne({ username: cleanUsername });
            
            if (user && user.searchData) {
                delete user.searchData.pricingData;
                await user.save();
                return true;
            }
            
            return false;
        } catch (error) {
            console.error('[Pricing] Error clearing cached data:', error.message);
            return false;
        }
    }
}

module.exports = new PricingService(); 