const SharedBrowserManager = require('./sharedBrowserManager');

class BrowserMonitor {
  constructor() {
    this.browserManager = SharedBrowserManager.getInstance();
    this.monitoringInterval = null;
    this.stats = {
      totalRequests: 0,
      successfulRequests: 0,
      failedRequests: 0,
      averageResponseTime: 0,
      startTime: Date.now(),
      lastReset: Date.now()
    };
  }

  startMonitoring(intervalMs = 30000) {
    if (this.monitoringInterval) {
      this.stopMonitoring();
    }

    console.log(`[BrowserMonitor] Starting monitoring with ${intervalMs}ms interval`);
    
    this.monitoringInterval = setInterval(() => {
      this.logStatus();
    }, intervalMs);

    // Log initial status
    this.logStatus();
  }

  stopMonitoring() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
      console.log('[BrowserMonitor] Monitoring stopped');
    }
  }

  logStatus() {
    const status = this.browserManager.getStatus();
    const uptime = Date.now() - this.stats.startTime;
    const uptimeMinutes = Math.floor(uptime / 60000);
    
    console.log('\n=== Browser Manager Status ===');
    console.log(`Uptime: ${uptimeMinutes} minutes`);
    console.log(`Browsers: ${status.browsers}`);
    console.log(`Pages: ${status.pages}`);
    console.log(`Initialized: ${status.isInitialized}`);
    console.log(`Max Total Pages: ${status.maxTotalPages}`);
    console.log(`Max Queue Size: ${status.maxQueueSize}`);
    
    if (status.queues && status.queues.length > 0) {
      console.log('\nQueue Status:');
      status.queues.forEach((queue, index) => {
        const status = queue.isClosed ? 'CLOSED' : 'ACTIVE';
        console.log(`  Queue ${index}: ${queue.queueSize} pending, ${queue.queuePending} running - ${status}`);
      });
    }
    
    console.log('\nPerformance Stats:');
    console.log(`  Total Requests: ${this.stats.totalRequests}`);
    console.log(`  Successful: ${this.stats.successfulRequests}`);
    console.log(`  Failed: ${this.stats.failedRequests}`);
    
    if (this.stats.totalRequests > 0) {
      const successRate = ((this.stats.successfulRequests / this.stats.totalRequests) * 100).toFixed(2);
      console.log(`  Success Rate: ${successRate}%`);
    }
    
    if (this.stats.averageResponseTime > 0) {
      console.log(`  Avg Response Time: ${this.stats.averageResponseTime.toFixed(2)}ms`);
    }
    
    console.log('=============================\n');
  }

  recordRequest(success, responseTime) {
    this.stats.totalRequests++;
    
    if (success) {
      this.stats.successfulRequests++;
    } else {
      this.stats.failedRequests++;
    }
    
    // Update average response time
    if (responseTime) {
      const currentAvg = this.stats.averageResponseTime;
      const totalRequests = this.stats.totalRequests;
      this.stats.averageResponseTime = (currentAvg * (totalRequests - 1) + responseTime) / totalRequests;
    }
  }

  resetStats() {
    this.stats = {
      totalRequests: 0,
      successfulRequests: 0,
      failedRequests: 0,
      averageResponseTime: 0,
      startTime: Date.now(),
      lastReset: Date.now()
    };
    console.log('[BrowserMonitor] Stats reset');
  }

  getStats() {
    return {
      ...this.stats,
      uptime: Date.now() - this.stats.startTime,
      status: this.browserManager.getStatus()
    };
  }

  async restartBrowserPool() {
    console.log('[BrowserMonitor] Restarting browser pool...');
    const startTime = Date.now();
    
    try {
      await this.browserManager.restart();
      const duration = Date.now() - startTime;
      console.log(`[BrowserMonitor] Browser pool restarted successfully in ${duration}ms`);
      return true;
    } catch (error) {
      console.error('[BrowserMonitor] Failed to restart browser pool:', error);
      return false;
    }
  }

  async healthCheck() {
    try {
      const status = this.browserManager.getStatus();
      
      // Check if we have any active pages
      if (status.pages === 0) {
        console.log('[BrowserMonitor] Health check failed: No active pages');
        return false;
      }
      
      // Check if any queues are overloaded
      const overloadedQueues = status.queues.filter(q => 
        q.queueSize > status.maxQueueSize * 0.8
      );
      
      if (overloadedQueues.length > 0) {
        console.log(`[BrowserMonitor] Health check warning: ${overloadedQueues.length} overloaded queues`);
      }
      
      // Check if any pages are closed
      const closedPages = status.queues.filter(q => q.isClosed);
      
      if (closedPages.length > 0) {
        console.log(`[BrowserMonitor] Health check warning: ${closedPages.length} closed pages`);
      }
      
      return true;
    } catch (error) {
      console.error('[BrowserMonitor] Health check failed:', error);
      return false;
    }
  }
}

// Create singleton instance
const browserMonitor = new BrowserMonitor();

// Auto-start monitoring in development
if (process.env.NODE_ENV === 'development') {
  browserMonitor.startMonitoring(60000); // Log every minute in development
}

module.exports = browserMonitor;
