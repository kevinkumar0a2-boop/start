const { chromium } = require('playwright');
const PQueue = require('p-queue').default;

// Shared configuration for lightweight operation
const SHARED_BROWSER_OPTIONS = {
  headless: true,
  args: [
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-dev-shm-usage',
    '--disable-accelerated-2d-canvas',
    '--no-first-run',
    '--no-zygote',
    '--disable-gpu',
    '--disable-web-security',
    '--disable-features=VizDisplayCompositor',
    '--disable-background-timer-throttling',
    '--disable-backgrounding-occluded-windows',
    '--disable-renderer-backgrounding',
    '--disable-features=TranslateUI',
    '--disable-ipc-flooding-protection',
    '--memory-pressure-off',
    '--max_old_space_size=2048', // Reduced from 4096
    '--disable-extensions',
    '--disable-plugins',
    '--disable-images',
    '--disable-javascript-harmony-shipping',
    '--disable-default-apps',
    '--disable-sync',
    '--disable-translate',
    '--hide-scrollbars',
    '--mute-audio',
    '--no-default-browser-check',
    '--no-pings',
    '--disable-background-networking',
    '--aggressive-cache-discard',
    '--disable-cache',
    '--disable-application-cache',
    '--disable-offline-load-stale-cache',
    '--disk-cache-size=0',
    '--disable-sync-preferences',
    '--disable-blink-features=AutomationControlled'
  ]
};

const SHARED_CONTEXT_OPTIONS = {
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
  viewport: { width: 1280, height: 720 }, // Reduced from 1920x1080
  deviceScaleFactor: 1,
  isMobile: false,
  hasTouch: false,
  javaScriptEnabled: true,
  acceptDownloads: false,
  ignoreHTTPSErrors: true,
  extraHTTPHeaders: {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Sec-Ch-Ua': '"Not A(Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1'
  }
};

// Shared browser pool configuration
const SHARED_CONFIG = {
  BROWSER_POOL_SIZE: 2, // Reduced from 5/3
  PAGES_PER_BROWSER: 3, // Reduced from 10/5
  MAX_QUEUE_SIZE: 50,   // Reduced from 100/300
  MAX_RETRIES: 2,       // Reduced from 3
  INITIAL_TIMEOUT: 20000, // Reduced from 30000
  PAGE_LOAD_TIMEOUT: 30000, // Reduced from 45000
  QUEUE_TIMEOUT: 45000  // Reduced from 60000
};

class SharedBrowserManager {
  constructor() {
    this.browsers = [];
    this.pagePools = [];
    this.isInitialized = false;
    this.initializationPromise = null;
    this.cleanupInProgress = false;
  }

  // Singleton pattern
  static getInstance() {
    if (!SharedBrowserManager.instance) {
      SharedBrowserManager.instance = new SharedBrowserManager();
    }
    return SharedBrowserManager.instance;
  }

  async initialize() {
    if (this.isInitialized) {
      return;
    }

    if (this.initializationPromise) {
      return this.initializationPromise;
    }

    this.initializationPromise = this._initializePool();
    try {
      await this.initializationPromise;
      this.isInitialized = true;
    } catch (error) {
      this.initializationPromise = null;
      throw error;
    }
  }

  async _initializePool() {
    console.log(`[SharedBrowser] Starting shared pool with ${SHARED_CONFIG.BROWSER_POOL_SIZE} browsers and ${SHARED_CONFIG.PAGES_PER_BROWSER} pages each`);
    
    for (let i = 0; i < SHARED_CONFIG.BROWSER_POOL_SIZE; i++) {
      try {
        const browser = await chromium.launch(SHARED_BROWSER_OPTIONS);
        this.browsers.push(browser);
        
        for (let j = 0; j < SHARED_CONFIG.PAGES_PER_BROWSER; j++) {
          try {
            const context = await browser.newContext(SHARED_CONTEXT_OPTIONS);
            const page = await context.newPage();
            
            // Lightweight resource blocking
            await page.route('**/*', (route) => {
              const url = route.request().url();
              const resourceType = route.request().resourceType();
              
              // Block heavy resources
              const blockedDomains = [
                'google-analytics.com', 'googletagmanager.com', 'facebook.com',
                'doubleclick.net', 'googlesyndication.com', 'amazon-adsystem.com',
                'adnxs.com', 'adsystem.com', 'hotjar.com', 'mixpanel.com',
                'cloudflare.com', 'cdnjs.cloudflare.com', 'jsdelivr.net',
                'fonts.googleapis.com', 'fonts.gstatic.com', 'ajax.googleapis.com'
              ];
              
              const blockedTypes = ['image', 'stylesheet', 'font', 'media'];
              
              const isBlockedDomain = blockedDomains.some(domain => url.includes(domain));
              
              if (isBlockedDomain || blockedTypes.includes(resourceType)) {
                route.abort();
              } else {
                route.continue();
              }
            });
            
            // Basic anti-detection
            await page.addInitScript(() => {
              Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
              Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
              Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });
              window.chrome = { runtime: {} };
            });
            
            const queue = new PQueue({ 
              concurrency: 1,
              timeout: SHARED_CONFIG.QUEUE_TIMEOUT
            });
            
            this.pagePools.push({ page, queue, context, browser });
            console.log(`[SharedBrowser] Created page ${this.pagePools.length}/${SHARED_CONFIG.BROWSER_POOL_SIZE * SHARED_CONFIG.PAGES_PER_BROWSER}`);
          } catch (pageError) {
            console.error(`[SharedBrowser] Error creating page ${j} for browser ${i}:`, pageError);
          }
        }
      } catch (browserError) {
        console.error(`[SharedBrowser] Error creating browser ${i}:`, browserError);
      }
    }
    
    console.log(`[SharedBrowser] Pool initialization complete. Created ${this.pagePools.length} pages`);
  }

  async getAvailablePage() {
    await this.initialize();
    
    if (this.pagePools.length === 0) {
      throw new Error('No available page pools');
    }
    
    // Find the least busy page
    let selectedPool = this.pagePools[0];
    let minQueueSize = selectedPool.queue.size + selectedPool.queue.pending;
    
    for (const pool of this.pagePools) {
      const currentQueueSize = pool.queue.size + pool.queue.pending;
      if (currentQueueSize < minQueueSize) {
        minQueueSize = currentQueueSize;
        selectedPool = pool;
      }
    }
    
    if (minQueueSize > SHARED_CONFIG.MAX_QUEUE_SIZE) {
      throw new Error('All queues are busy, try again later');
    }
    
    return selectedPool;
  }

  async executeTask(taskFunction, taskName = 'unknown') {
    const pool = await this.getAvailablePage();
    
    return pool.queue.add(async () => {
      try {
        // Check if page is still valid
        if (pool.page.isClosed && pool.page.isClosed()) {
          throw new Error('Page is closed');
        }
        
        const result = await taskFunction(pool.page);
        return result;
      } catch (error) {
        console.error(`[SharedBrowser] Task error for ${taskName}:`, error);
        throw error;
      }
    });
  }

  async navigateToUrl(page, url, options = {}) {
    const defaultOptions = {
      timeout: SHARED_CONFIG.PAGE_LOAD_TIMEOUT,
      waitUntil: 'domcontentloaded'
    };
    
    await page.goto(url, { ...defaultOptions, ...options });
    
    // Handle Cloudflare challenge if present
    try {
      await page.waitForFunction(() => {
        return !document.querySelector('#challenge-form') && 
               !document.querySelector('.cf-browser-verification') &&
               !document.querySelector('#cf-please-wait');
      }, { timeout: 5000 });
    } catch (error) {
      // Cloudflare challenge not detected or already passed
    }
  }

  getStatus() {
    return {
      browsers: this.browsers.length,
      pages: this.pagePools.length,
      isInitialized: this.isInitialized,
      queues: this.pagePools.map((pool, idx) => ({
        index: idx,
        queueSize: pool.queue.size,
        queuePending: pool.queue.pending,
        isClosed: pool.page.isClosed ? pool.page.isClosed() : false
      })),
      maxTotalPages: SHARED_CONFIG.BROWSER_POOL_SIZE * SHARED_CONFIG.PAGES_PER_BROWSER,
      maxQueueSize: SHARED_CONFIG.MAX_QUEUE_SIZE
    };
  }

  async cleanup() {
    if (this.cleanupInProgress) {
      return;
    }
    
    this.cleanupInProgress = true;
    console.log('[SharedBrowser] Starting cleanup...');
    
    try {
      for (const pool of this.pagePools) {
        try {
          await pool.context.close();
        } catch (error) {
          console.error('[SharedBrowser] Error closing context:', error);
        }
      }
      
      for (const browser of this.browsers) {
        try {
          await browser.close();
        } catch (error) {
          console.error('[SharedBrowser] Error closing browser:', error);
        }
      }
      
      this.pagePools.length = 0;
      this.browsers.length = 0;
      this.isInitialized = false;
      this.initializationPromise = null;
      this.cleanupInProgress = false;
      
      console.log('[SharedBrowser] Cleanup complete');
    } catch (error) {
      this.cleanupInProgress = false;
      console.error('[SharedBrowser] Error during cleanup:', error);
    }
  }

  async restart() {
    console.log('[SharedBrowser] Restarting browser pool...');
    await this.cleanup();
    await this.initialize();
  }
}

// Handle process termination
const manager = SharedBrowserManager.getInstance();
process.on('SIGINT', () => manager.cleanup());
process.on('SIGTERM', () => manager.cleanup());

module.exports = SharedBrowserManager;
