const fs = require('fs').promises;
const path = require('path');
const config = require('../config/config');

class MerchantManager {
  constructor() {
    this.merchantsFile = path.join(__dirname, '../config/merchants.json');
    this.currentMerchantIndex = 0;
    this.merchants = [];
    this.loadMerchants();
  }

  /**
   * Load merchants from file
   */
  async loadMerchants() {
    try {
      const data = await fs.readFile(this.merchantsFile, 'utf8');
      this.merchants = JSON.parse(data);
    } catch (error) {
      // If file doesn't exist, initialize from central config if available; otherwise keep empty
      const taoPay = (config && config.taoPay) ? config.taoPay : null;
      const credsArray = (taoPay && Array.isArray(taoPay.credentials)) ? taoPay.credentials : [];

      if (credsArray.length > 0) {
        this.merchants = credsArray.map((cred, index) => ({
          id: cred.merchId,
          secretKey: cred.secretKey,
          name: cred.name || `Merchant ${index + 1}`,
          active: true,
          createdAt: new Date().toISOString()
        }));
      } else if (taoPay && taoPay.merchId && taoPay.secretKey) {
        this.merchants = [{
          id: taoPay.merchId,
          secretKey: taoPay.secretKey,
          name: 'Merchant 1',
          active: true,
          createdAt: new Date().toISOString()
        }];
      } else {
        this.merchants = [];
      }
    }
  }

  /**
   * Save merchants to file
   */
  async saveMerchants() {
    try {
      const configDir = path.dirname(this.merchantsFile);
      await fs.mkdir(configDir, { recursive: true });
      await fs.writeFile(this.merchantsFile, JSON.stringify(this.merchants, null, 2));
    } catch (error) {
      console.error('Error saving merchants:', error);
    }
  }

  /**
   * Get random active merchant
   */
  getRandomMerchant() {
    const activeMerchants = this.merchants.filter(m => m.active);
    if (activeMerchants.length === 0) {
      throw new Error('No active merchants available');
    }
    
    const randomIndex = Math.floor(Math.random() * activeMerchants.length);
    return activeMerchants[randomIndex];
  }

  /**
   * Get next merchant in rotation
   */
  getNextMerchant() {
    const activeMerchants = this.merchants.filter(m => m.active);
    if (activeMerchants.length === 0) {
      throw new Error('No active merchants available');
    }
    
    this.currentMerchantIndex = (this.currentMerchantIndex + 1) % activeMerchants.length;
    return activeMerchants[this.currentMerchantIndex];
  }

  /**
   * Get current merchant
   */
  getCurrentMerchant() {
    const activeMerchants = this.merchants.filter(m => m.active);
    if (activeMerchants.length === 0) {
      throw new Error('No active merchants available');
    }
    
    return activeMerchants[this.currentMerchantIndex];
  }

  /**
   * Add new merchant
   */
  async addMerchant(merchantData) {
    const newMerchant = {
      id: merchantData.id,
      secretKey: merchantData.secretKey,
      name: merchantData.name || `Merchant ${this.merchants.length + 1}`,
      active: true,
      createdAt: new Date().toISOString(),
      addedBy: merchantData.addedBy || 'system'
    };

    this.merchants.push(newMerchant);
    await this.saveMerchants();
    return newMerchant;
  }

  /**
   * Update merchant
   */
  async updateMerchant(merchantId, updates) {
    const merchantIndex = this.merchants.findIndex(m => m.id === merchantId);
    if (merchantIndex === -1) {
      throw new Error('Merchant not found');
    }

    this.merchants[merchantIndex] = {
      ...this.merchants[merchantIndex],
      ...updates,
      updatedAt: new Date().toISOString()
    };

    await this.saveMerchants();
    return this.merchants[merchantIndex];
  }

  /**
   * Delete merchant
   */
  async deleteMerchant(merchantId) {
    const merchantIndex = this.merchants.findIndex(m => m.id === merchantId);
    if (merchantIndex === -1) {
      throw new Error('Merchant not found');
    }

    this.merchants.splice(merchantIndex, 1);
    await this.saveMerchants();
    return true;
  }

  /**
   * Toggle merchant active status
   */
  async toggleMerchant(merchantId) {
    const merchant = this.merchants.find(m => m.id === merchantId);
    if (!merchant) {
      throw new Error('Merchant not found');
    }

    merchant.active = !merchant.active;
    merchant.updatedAt = new Date().toISOString();
    await this.saveMerchants();
    return merchant;
  }

  /**
   * Get all merchants
   */
  getAllMerchants() {
    return this.merchants.map(m => ({
      ...m,
      secretKey: m.secretKey ? '***' + m.secretKey.slice(-4) : '***'
    }));
  }

  /**
   * Get merchant by ID
   */
  getMerchantById(merchantId) {
    const merchant = this.merchants.find(m => m.id === merchantId);
    if (!merchant) {
      throw new Error('Merchant not found');
    }
    return merchant;
  }

  /**
   * Get merchant statistics
   */
  getMerchantStats() {
    const total = this.merchants.length;
    const active = this.merchants.filter(m => m.active).length;
    const inactive = total - active;

    return {
      total,
      active,
      inactive,
      currentIndex: this.currentMerchantIndex
    };
  }
}

module.exports = MerchantManager;
