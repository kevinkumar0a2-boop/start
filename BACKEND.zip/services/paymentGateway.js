const md5 = require('md5');
const { playwrightPaymentRequest, playwrightInquiryRequest } = require('./playwrightPayment');

// Constants
const MERCHANT_ID = '85071336';
const PRIVATE_KEY = 'f7b3eb7e62f0c439763048c403ee158a';
const BASE_URL = 'https://xyu10.top';

class PaymentGateway {
    constructor(baseUrl = BASE_URL, merchantId = MERCHANT_ID, privateKey = PRIVATE_KEY) {
        this.baseUrl = baseUrl.replace(/\/$/, ''); // Remove trailing slash
        this.merchantId = merchantId;
        this.privateKey = privateKey;
    }

    /**
     * Handle payment gateway request errors
     * @param {Error} error - Error object
     * @returns {Error} Formatted error
     */
    handleRequestError(error) {
        error.isGatewayError = true;
        return error;
    }

    /**
     * Send request to payment gateway using Playwright only
     * @param {string} path - API endpoint path
     * @param {Object} data - Request data
     * @returns {Promise<Object>} Response data
     */
    async sendRequest(path, data) {
        // Internal validation helper
        const validatePaymentData = (data) => {
            const errors = [];
            const requiredFields = {
                mch_id: { type: 'string', required: true },
                mch_order_no: { type: 'string', required: true },
                notifyUrl: { type: 'string', required: false, maxLength: 200 },
                page_url: { type: 'string', required: false, maxLength: 200 },
                trade_amount: { type: 'number', required: false },
                currency: { type: 'string', required: false },
                pay_type: { type: 'string', required: false },
                payer_phone: { type: 'number', required: false },
                attach: { type: 'string', required: false, maxLength: 200 }
            };
            for (const [field, rules] of Object.entries(requiredFields)) {
                const value = data[field];
                if (rules.required && (value === undefined || value === null || value === '')) {
                    errors.push(`${field} is required`);
                    continue;
                }
                if (!rules.required && (value === undefined || value === null)) {
                    continue;
                }
                if (rules.type === 'number') {
                    if (typeof value !== 'number' && isNaN(Number(value))) {
                        errors.push(`${field} must be a number`);
                    }
                } else if (rules.type === 'string') {
                    if (typeof value !== 'string') {
                        errors.push(`${field} must be a string`);
                    }
                    if (rules.maxLength && value.length > rules.maxLength) {
                        errors.push(`${field} must not exceed ${rules.maxLength} bytes`);
                    }
                }
            }
            return {
                isValid: errors.length === 0,
                errors
            };
        };
        // Internal signature helper
        const generateSignature = (data) => {
            try {
                const signData = { ...data };
                delete signData.sign;
                delete signData.sign_type;
                const sortedKeys = Object.keys(signData).sort();
                let concatenatedString = '';
                for (const key of sortedKeys) {
                    const value = signData[key];
                    if (value !== null && value !== '' && key !== 'sign' && key !== 'sign_type') {
                        concatenatedString += `${key}=${value}&`;
                    }
                }
                concatenatedString = concatenatedString.slice(0, -1) + `&key=${this.privateKey}`;
                return md5(concatenatedString).toLowerCase();
            } catch (error) {
                console.error('Error generating signature:', error);
                throw new Error('Failed to generate signature');
            }
        };
        try {
            // Validate request data
            const validation = validatePaymentData(data);
            if (!validation.isValid) {
                throw new Error(`Invalid payment data: ${validation.errors.join(', ')}`);
            }
            // Generate signature and add to data
            const sign = generateSignature(data);
            const requestData = {
                ...data,
                sign,
                sign_type: 'MD5'
            };
            // Log request data for debugging
            const requestInfo = {
                url: `${this.baseUrl}${path}`,
                data: requestData
            };
            
            // Determine if this is an inquiry request based on the path
            const isInquiryRequest = path.includes('/api/payquery/');
            
            // Use appropriate Playwright function based on request type
            let response;
            if (isInquiryRequest) {
                response = await playwrightInquiryRequest(requestData);
            } else {
                response = await playwrightPaymentRequest(requestData);
            }
            
            // Log response for debugging
        
            if (!response || typeof response !== 'object') {
                throw new Error('Invalid response format');
            }
            return response;
        } catch (error) {
            console.error('Payment gateway request error:', error);
            throw this.handleRequestError(error);
        }
    }

    /**
     * Initiate payment collection
     * @param {Object} data - Payment data
     * @returns {Promise<Object>} Response data
     */
    async initiatePayment(data) {
        return this.sendRequest('/api/payGate/payCollect', data);
    }

    /**
     * Query order status
     * @param {Object} data - Query data
     * @returns {Promise<Object>} Response data
     */
    async queryOrder(data) {
        return this.sendRequest('/api/query/payOrder', data);
    }

    /**
     * Initiate payment order (transfer)
     * @param {Object} data - Order data
     * @returns {Promise<Object>} Response data
     */
    async initiateOrder(data) {
        return this.sendRequest('/api/payGate/payOrder', data);
    }
}

module.exports = PaymentGateway; 
