const SharedBrowserManager = require('./sharedBrowserManager');

const PAYMENT_URL = 'https://mrch.taopay.in/api/v1/order';

// Get shared browser manager instance
const browserManager = SharedBrowserManager.getInstance();

// Status for monitoring
function getPaymentStatus() {
  return {
    ...browserManager.getStatus(),
    service: 'payment'
  };
}

// Improved payment request with error handling
async function sendPaymentRequest(page, paymentData) {
  try {
    if (page.isClosed && page.isClosed()) {
      throw new Error('Page is closed');
    }

    // Navigate to payment URL if not already there
    const currentUrl = page.url();
    if (!currentUrl.includes('xyu10.top')) {
      await browserManager.navigateToUrl(page, PAYMENT_URL);
    }

    // Use page.evaluate to send a POST request from within the browser context
    const response = await page.evaluate(async ({ url, data }) => {
      try {
        const formBody = Object.entries(data)
          .map(([key, value]) => encodeURIComponent(key) + '=' + encodeURIComponent(value))
          .join('&');
          
        const res = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept': 'application/json'
          },
          body: formBody
        });
          
        const text = await res.text();
        try {
          return { success: true, data: JSON.parse(text) };
        } catch {
          return { success: true, data: { raw: text } };
        }
      } catch (err) {
        return { success: false, error: err.message };
      }
    }, { url: PAYMENT_URL, data: paymentData });

    if (response.success) {
      return response.data;
    } else {
      console.error(`[Payment] Request failed:`, response.error);
      return { error: true, message: response.error };
    }
  } catch (err) {
    console.error(`[Payment] sendPaymentRequest error:`, err);
    return { error: true, message: err.message, stack: err.stack };
  }
}

/**
 * Send a payment request using Playwright to bypass Cloudflare anti-bot.
 * @param {Object} paymentData - The payment data to send (must include all required fields and signature).
 * @returns {Promise<Object>} - The response from the payment gateway.
 */
async function playwrightPaymentRequest(paymentData) {
  try {
    const result = await browserManager.executeTask(
      (page) => sendPaymentRequest(page, paymentData),
      'payment_request'
    );
    
    return result;
  } catch (error) {
    console.error(`[Payment] playwrightPaymentRequest error:`, error);
    return { error: true, message: error.message, stack: error.stack };
  }
}

// Cleanup function for graceful shutdown
async function cleanupPaymentBrowsers() {
  try {
    await browserManager.cleanup();
  } catch (err) {
    console.error('[Payment Cleanup] Error during cleanup:', err);
  }
}

// Ensure cleanup on process exit
process.on('exit', async () => { 
  try { 
    await cleanupPaymentBrowsers(); 
  } catch {} 
});
process.on('SIGINT', async () => { 
  try { 
    await cleanupPaymentBrowsers(); 
  } catch {} 
  process.exit(); 
});
process.on('SIGTERM', async () => { 
  try { 
    await cleanupPaymentBrowsers(); 
  } catch {} 
  process.exit(); 
});

module.exports = { 
  playwrightPaymentRequest, 
  getPaymentStatus,
  cleanupPaymentBrowsers
}; 
