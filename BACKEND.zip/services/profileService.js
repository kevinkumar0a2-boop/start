const { downloadAndConvertToBase64 } = require('../utils/imageHandler');
const { sendUserSearchLog, sendErrorLog } = require('../utils/telegramBot');
const PasswordService = require('./passwordService');
const requestManager = require('./requestManager');
const Profile = require('../models/Profile');
const playwrightProfileScraper = require('./playwrightProfileScraper');

// Enhanced in-memory cache with LRU-like behavior
const profileCache = new Map();
const CACHE_TTL = 10 * 60 * 1000; // Increased to 10 minutes
const MAX_CACHE_SIZE = 1000; // Maximum cache entries

// Cache management
function getCachedProfile(username) {
    const entry = profileCache.get(username);
    if (entry && (Date.now() - entry.timestamp < CACHE_TTL)) {
        // Update access time for LRU behavior
        entry.lastAccessed = Date.now();
        return entry.data;
    }
    if (entry) {
        profileCache.delete(username);
    }
    return null;
}

function setCachedProfile(username, data) {
    // Implement LRU-like eviction
    if (profileCache.size >= MAX_CACHE_SIZE) {
        let oldestKey = null;
        let oldestTime = Date.now();
        
        for (const [key, entry] of profileCache.entries()) {
            if (entry.lastAccessed < oldestTime) {
                oldestTime = entry.lastAccessed;
                oldestKey = key;
            }
        }
        
        if (oldestKey) {
            profileCache.delete(oldestKey);
        }
    }
    
    profileCache.set(username, { 
        data, 
        timestamp: Date.now(),
        lastAccessed: Date.now()
    });
}

// Database connection pooling optimization
const mongoose = require('mongoose');
const config = require('../config/config');

// Optimize database queries - use options from central config

// Update mongoose connection if not already optimized
if (mongoose.connection.readyState === 0) {
    mongoose.connect(config.database.uri, config.database.options);
}

class ProfileService {
    constructor() {
        this.STORAGE_DURATION = 30 * 60 * 1000; // 30 minutes
        this.BATCH_SIZE = 10; // For batch operations
    }

    async getTempStorageData(username) {
        try {
            // Use lean() for faster queries without mongoose document overhead
            const profile = await Profile.findOne({ username }).lean().exec();
            return profile ? profile.data : null;
        } catch (error) {
            console.error('[ProfileService] Database error:', error);
            return null;
        }
    }

    async setTempStorageData(username, data) {
        try {
            // Use updateOne with upsert for better performance
            await Profile.updateOne(
                { username },
                { username, data, updatedAt: new Date() },
                { upsert: true }
            );
        } catch (error) {
            console.error('[ProfileService] Error setting temp storage:', error);
        }
    }

    async getProfileData(username) {
        const start = Date.now();
        try {
            // Check in-memory cache first (fastest)
            const cached = getCachedProfile(username);
            if (cached) {
        
                return { result: [ { user: cached.data } ] };
            }

            // Check if we're in cooldown period
            if (requestManager.isInCooldown()) {
                throw new Error('Rate limit cooldown in effect');
            }

            // Check temporary storage (database cache)
            const tempData = await this.getTempStorageData(username);
            if (tempData) {
                setCachedProfile(username, tempData);
        
                return { result: [ { user: tempData.data } ] };
            }

            // Check request manager cache
            const cachedData = requestManager.getCachedData(username);
            if (cachedData) {
                // Store in temporary storage and memory cache
                await this.setTempStorageData(username, cachedData);
                setCachedProfile(username, cachedData);
        
                return { result: [ { user: cachedData.data } ] };
            }

            // Fetch using optimized Playwright scraper with retry mechanism
            let data = null;
            let playwrightError = null;
            
            try {
                data = await playwrightProfileScraper.getProfileDataWithPlaywright(username);
            } catch (error) {
                playwrightError = error;
                console.error(`[ProfileService] Playwright error for ${username}:`, error);
                
                // If it's a timeout error, try to restart the pool
                if (error.message && error.message.includes('Timeout')) {
                    try {
                        console.log(`[ProfileService] Attempting to restart Playwright pool for ${username}`);
                        await playwrightProfileScraper.cleanup();
                        data = await playwrightProfileScraper.getProfileDataWithPlaywright(username);
                    } catch (retryError) {
                        console.error(`[ProfileService] Retry failed for ${username}:`, retryError);
                        throw new Error(`Service temporarily unavailable. Please try again later.`);
                    }
                } else {
                    throw error;
                }
            }
            
            if (!data || data.error) {
                throw new Error(data && data.error ? data.error : 'Unknown error from Playwright scraper');
            }
            
            const userData = data?.result?.[0]?.user;
            if (!userData) {
                throw new Error('Profile data not found in response');
            }

            // Optimize image processing - only download if needed
            if (userData.profile_pic_url && !userData.profile_pic_url.startsWith('data:')) {
                try {
                    userData.profile_pic_url = await downloadAndConvertToBase64(userData.profile_pic_url);
                } catch (imageError) {
                    console.error('[ProfileService] Image processing error:', imageError);
                    // Continue without image if processing fails
                }
            }

            // Generate password based on user data
            userData.generated_password = PasswordService.generatePassword({
                username: userData.username,
                fullName: userData.full_name || '',
                bio: userData.biography || ''
            });

            // Cache the result
            const result = { data: userData, success: true };
            await this.setTempStorageData(username, result);
            setCachedProfile(username, result);

    
            return { result: [ { user: userData } ] };

        } catch (error) {
            console.error(`[ProfileService] Error for ${username}:`, error);
            throw error;
        }
    }

    // Batch operations for better performance
    async getMultipleProfiles(usernames) {
        const results = [];
        const batchSize = this.BATCH_SIZE;
        
        for (let i = 0; i < usernames.length; i += batchSize) {
            const batch = usernames.slice(i, i + batchSize);
            const batchPromises = batch.map(username => 
                this.getProfileData(username).catch(error => ({
                    username,
                    error: error.message
                }))
            );
            
            const batchResults = await Promise.allSettled(batchPromises);
            results.push(...batchResults.map(result => 
                result.status === 'fulfilled' ? result.value : result.reason
            ));
        }
        
        return results;
    }

    // Cache statistics
    getCacheStats() {
        return {
            size: profileCache.size,
            maxSize: MAX_CACHE_SIZE,
            ttl: CACHE_TTL,
            entries: Array.from(profileCache.keys())
        };
    }

    // Clear cache
    clearCache() {
        profileCache.clear();

    }
}

module.exports = new ProfileService(); 
