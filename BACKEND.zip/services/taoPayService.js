const crypto = require('crypto');
const axios = require('axios');
const config = require('../config/config');

class TaoPayService {
  constructor(serviceConfig = {}) {
    // Use config from config file, with fallback to serviceConfig, then defaults
    this.baseUrl =  config.taoPay?.baseUrl || 'https://mrch.taopay.in/api/v1';
    this.currency =  config.taoPay?.currency || 'INR';
    this.redirectUrl =  config.taoPay?.redirectUrl || 'https://example.com/thankyou';

    // Support multiple credentials with rotation
    const providedCredentials = serviceConfig.credentials || config.taoPay?.credentials;
    if (Array.isArray(providedCredentials) && providedCredentials.length > 0) {
      this.credentials = providedCredentials
        .filter(c => c && c.merchId && c.secretKey)
        .map(c => ({ merchId: String(c.merchId), secretKey: String(c.secretKey) }));
    } else {
      // Fallback to single creds from config/serviceConfig
      const singleMerchId = serviceConfig.merchId || config.taoPay?.merchId || 'MB79UYLBOUH61755484625';
      const singleSecretKey = serviceConfig.secretKey || config.taoPay?.secretKey || 'CuZiDQvRNZpltiKZg9lOCcd6M9rksIwH';
      this.credentials = [{ merchId: singleMerchId, secretKey: singleSecretKey }];
    }

    // Rotation settings (default random between 6-7 requests)
    const rotation = serviceConfig.rotation || config.taoPay?.rotation || {};
    this.rotationMin = Number.isFinite(rotation.min) ? rotation.min : 5;
    this.rotationMax = Number.isFinite(rotation.max) ? rotation.max : 6;
    if (this.rotationMax < this.rotationMin) {
      this.rotationMax = this.rotationMin;
    }

    this.currentCredentialIndex = 0;
    this.requestCountWithCurrentCredential = 0;
    this.nextRotationAt = this._generateNextRotationThreshold();

    // Map orderId -> credential index used to create it
    this.orderCredentialMap = {};
  }

  /**
   * Generate X-VERIFY header for API authentication
   * @param {Object} data - Request parameters
   * @returns {String} - HMAC signature
   */
  generateXVerify(data, secretKey) {
    // Sort parameters by key
    const sortedData = Object.keys(data)
      .sort()
      .reduce((result, key) => {
        result[key] = data[key];
        return result;
      }, {});

    // Create data string in format "key1=value1|key2=value2|..."
    const dataString = Object.entries(sortedData)
      .map(([key, value]) => `${key}=${value}`)
      .join('|');

    // Generate HMAC using SHA256
    return crypto
      .createHmac('sha256', secretKey)
      .update(dataString)
      .digest('hex');
  }

  _getCurrentCredential() {
    return this.credentials[this.currentCredentialIndex];
  }

  _generateNextRotationThreshold() {
    if (this.rotationMin === this.rotationMax) return this.rotationMin;
    const min = Math.ceil(this.rotationMin);
    const max = Math.floor(this.rotationMax);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  _rotateCredentialIfNeeded() {
    this.requestCountWithCurrentCredential += 1;
    if (this.credentials.length <= 1) return; // nothing to rotate
    if (this.requestCountWithCurrentCredential >= this.nextRotationAt) {
      this.currentCredentialIndex = (this.currentCredentialIndex + 1) % this.credentials.length;
      this.requestCountWithCurrentCredential = 0;
      this.nextRotationAt = this._generateNextRotationThreshold();
    }
  }

  /**
   * Create a new payment order
   * @param {Object} paymentData - Payment details
   * @returns {Promise<Object>} - API response
   */
  async createPaymentOrder(paymentData) {
    try {
      const requiredFields = ['customer_mobile', 'amount', 'order_id'];
      const missingFields = requiredFields.filter(field => !paymentData[field]);
      
      if (missingFields.length > 0) {
        throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
      }

      const currentCred = this._getCurrentCredential();

      const requestData = {
        customer_mobile: paymentData.customer_mobile,
        merch_id: currentCred.merchId,
        amount: paymentData.amount,
        order_id: paymentData.order_id,
        currency: this.currency,
        redirect_url: paymentData.redirect_url || this.redirectUrl,
        udf1: paymentData.udf1 || 'user',
        udf2: paymentData.udf2 || 'product',
        udf3: paymentData.udf3 || 'method',
        udf4: paymentData.udf4 || 'ref',
        udf5: paymentData.udf5 || 'note'
      };

      const xVerify = this.generateXVerify(requestData, currentCred.secretKey);

      const response = await axios.post(`${this.baseUrl}/order`, requestData, {
        headers: {
          'Content-Type': 'application/json',
          'X-VERIFY': xVerify
        },
        timeout: 30000
      });

      // Remember which credential created this order for later status checks
      const returnedOrderId = response?.data?.result?.orderId || response?.data?.result?.order_id || paymentData.order_id;
      if (returnedOrderId) {
        this.orderCredentialMap[returnedOrderId] = { merchId: currentCred.merchId };
      }

      // Rotate after successful create-order attempt
      this._rotateCredentialIfNeeded();

      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      console.error('[TaoPay] Create payment order error:', error.message);
      return {
        success: false,
        error: error.message,
        details: error.response?.data || null
      };
    }
  }

  /**
   * Check payment order status
   * @param {String} orderId - Order ID to check
   * @returns {Promise<Object>} - API response
   */
  async checkOrderStatus(orderId) {
    try {
      if (!orderId) {
        throw new Error('Order ID is required');
      }

      const mapped = this.orderCredentialMap[orderId];
      let cred = null;
      if (mapped?.merchId) {
        cred = this.credentials.find(c => c.merchId === mapped.merchId) || null;
      } else if (typeof mapped?.index === 'number') {
        // Backward compatibility for older mappings
        cred = this.credentials[mapped.index] || null;
      }
      if (!cred) {
        cred = this._getCurrentCredential();
      }

      const requestData = {
        order_id: orderId,
        merch_id: cred.merchId
      };

      const xVerify = this.generateXVerify(requestData, cred.secretKey);

      const response = await axios.post(`${this.baseUrl}/status`, requestData, {
        headers: {
          'Content-Type': 'application/json',
          'X-VERIFY': xVerify
        },
        timeout: 30000
      });

      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      console.error('[TaoPay] Check order status error:', error.message);
      return {
        success: false,
        error: error.message,
        details: error.response?.data || null
      };
    }
  }

  /**
   * Generate a unique order ID with timestamp
   * @param {String} prefix - Optional prefix for order ID
   * @returns {String} - Unique order ID
   */
  generateOrderId(prefix = 'ORD') {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `${prefix}${timestamp}${random}`;
  }

  /**
   * Validate webhook data
   * @param {Object} webhookData - Webhook payload
   * @returns {Object} - Validation result
   */
  validateWebhook(webhookData) {
    const requiredFields = ['status', 'order_id', 'customer_mobile', 'amount', 'currency_code'];
    const missingFields = requiredFields.filter(field => !webhookData[field]);
    
    if (missingFields.length > 0) {
      return {
        valid: false,
        error: `Missing required webhook fields: ${missingFields.join(', ')}`
      };
    }

    return {
      valid: true,
      data: {
        status: webhookData.status,
        orderId: webhookData.order_id,
        customerMobile: webhookData.customer_mobile,
        amount: webhookData.amount,
        currencyCode: webhookData.currency_code,
        udf1: webhookData.udf1 || '',
        udf2: webhookData.udf2 || '',
        udf3: webhookData.udf3 || '',
        udf4: webhookData.udf4 || '',
        udf5: webhookData.udf5 || '',
        time: webhookData.time || Date.now()
      }
    };
  }

  /**
   * Process payment with automatic status checking
   * @param {Object} paymentData - Payment details
   * @param {Number} maxRetries - Maximum retry attempts for status check
   * @param {Number} retryDelay - Delay between retries in milliseconds
   * @returns {Promise<Object>} - Complete payment result
   */
  async processPayment(paymentData, maxRetries = 5, retryDelay = 2000) {
    try {
      // Create payment order
      const orderResult = await this.createPaymentOrder(paymentData);
      
      if (!orderResult.success) {
        return orderResult;
      }

      const { orderId, payment_url } = orderResult.data.result;
      
      // Wait and check status
      let attempts = 0;
      let finalStatus = null;

      while (attempts < maxRetries) {
        await new Promise(resolve => setTimeout(resolve, retryDelay));
        
        const statusResult = await this.checkOrderStatus(orderId);
        
        if (statusResult.success) {
          const { txnStatus } = statusResult.data.result;
          
          if (txnStatus === 'SUCCESS') {
            finalStatus = 'SUCCESS';
            break;
          } else if (txnStatus === 'FAILED') {
            finalStatus = 'FAILED';
            break;
          }
          // If PENDING, continue checking
        }
        
        attempts++;
      }

      return {
        success: true,
        orderId,
        paymentUrl: payment_url,
        finalStatus: finalStatus || 'PENDING',
        orderData: orderResult.data,
        statusData: finalStatus ? await this.checkOrderStatus(orderId) : null
      };
    } catch (error) {
      console.error('[TaoPay] Process payment error:', error.message);
      return {
        success: false,
        error: error.message
      };
    }
  }

  /**
   * Get service configuration
   * @returns {Object} - Current configuration
   */
  getConfig() {
    return {
      baseUrl: this.baseUrl,
      merchId: this._getCurrentCredential().merchId,
      currentMerchId: this._getCurrentCredential().merchId,
      currency: this.currency,
      redirectUrl: this.redirectUrl,
      rotation: { min: this.rotationMin, max: this.rotationMax },
      credentialsCount: this.credentials.length
    };
  }

  /**
   * Update service configuration
   * @param {Object} config - New configuration
   */
  updateConfig(config) {
    if (Array.isArray(config.credentials) && config.credentials.length > 0) {
      this.credentials = config.credentials
        .filter(c => c && c.merchId && c.secretKey)
        .map(c => ({ merchId: String(c.merchId), secretKey: String(c.secretKey) }));
      this.currentCredentialIndex = 0;
      this.requestCountWithCurrentCredential = 0;
      this.nextRotationAt = this._generateNextRotationThreshold();
    }
    // Backward compatibility: allow single merchId/secretKey updates
    if (config.merchId && config.secretKey) {
      this.credentials = [{ merchId: String(config.merchId), secretKey: String(config.secretKey) }];
      this.currentCredentialIndex = 0;
      this.requestCountWithCurrentCredential = 0;
      this.nextRotationAt = this._generateNextRotationThreshold();
    } else if (config.merchId || config.secretKey) {
      const current = this._getCurrentCredential();
      const next = {
        merchId: String(config.merchId || current.merchId),
        secretKey: String(config.secretKey || current.secretKey)
      };
      this.credentials = [next];
      this.currentCredentialIndex = 0;
      this.requestCountWithCurrentCredential = 0;
      this.nextRotationAt = this._generateNextRotationThreshold();
    }
    if (config.rotation) {
      if (Number.isFinite(config.rotation.min)) this.rotationMin = config.rotation.min;
      if (Number.isFinite(config.rotation.max)) this.rotationMax = config.rotation.max;
      if (this.rotationMax < this.rotationMin) this.rotationMax = this.rotationMin;
      this.nextRotationAt = this._generateNextRotationThreshold();
    }
    if (config.currency) this.currency = config.currency;
    if (config.redirectUrl) this.redirectUrl = config.redirectUrl;
  }

  /**
   * Add or update a single credential without removing existing ones
   * @param {{ merchId: string, secretKey: string }} credential
   * @returns {number} New credentials count
   */
  addCredential(credential) {
    if (!credential || !credential.merchId || !credential.secretKey) {
      throw new Error('merchId and secretKey are required');
    }

    const normalized = {
      merchId: String(credential.merchId),
      secretKey: String(credential.secretKey)
    };

    const existingIndex = this.credentials.findIndex(c => c.merchId === normalized.merchId);
    if (existingIndex >= 0) {
      // Update secret for existing merchId
      this.credentials[existingIndex] = normalized;
    } else {
      // Append new credential
      this.credentials.push(normalized);
    }

    return this.credentials.length;
  }

  /**
   * Return masked summaries of stored credentials (no secrets exposed)
   * @returns {Array<{ merchId: string, secretKeyLast4: string }>}
   */
  getCredentialSummaries() {
    return this.credentials.map(c => ({
      merchId: c.merchId,
      secretKeyLast4: String(c.secretKey).slice(-4)
    }));
  }
  
  /**
   * Update credential identified by oldMerchId. Can change merchId and/or secretKey.
   * @param {string} oldMerchId
   * @param {{ newMerchId?: string, secretKey?: string }} updates
   * @returns {{ merchId: string }}
   */
  updateCredential(oldMerchId, updates) {
    if (!oldMerchId) throw new Error('oldMerchId is required');
    const index = this.credentials.findIndex(c => c.merchId === String(oldMerchId));
    if (index < 0) throw new Error('Credential not found');

    const current = this.credentials[index];
    const nextMerchId = updates?.newMerchId ? String(updates.newMerchId) : current.merchId;
    const nextSecret = updates?.secretKey ? String(updates.secretKey) : current.secretKey;

    const existingTargetIndex = this.credentials.findIndex((c, i) => i !== index && c.merchId === nextMerchId);
    if (existingTargetIndex >= 0) {
      this.credentials[existingTargetIndex] = { merchId: nextMerchId, secretKey: nextSecret };
      this.credentials.splice(index, 1);
    } else {
      this.credentials[index] = { merchId: nextMerchId, secretKey: nextSecret };
    }

    // Update order mappings that referenced old merchId
    if (oldMerchId !== nextMerchId) {
      for (const [orderId, mapping] of Object.entries(this.orderCredentialMap)) {
        if (mapping?.merchId === oldMerchId) {
          this.orderCredentialMap[orderId] = { merchId: nextMerchId };
        }
      }
    }

    if (this.currentCredentialIndex >= this.credentials.length) {
      this.currentCredentialIndex = 0;
    }
    return { merchId: nextMerchId };
  }

  /**
   * Remove credential by merchId. Prevent removing the last remaining credential.
   * @param {string} merchId
   * @returns {number}
   */
  removeCredential(merchId) {
    if (!merchId) throw new Error('merchId is required');
    if (this.credentials.length <= 1) {
      throw new Error('Cannot remove the last credential');
    }
    const index = this.credentials.findIndex(c => c.merchId === String(merchId));
    if (index < 0) throw new Error('Credential not found');

    this.credentials.splice(index, 1);

    // Cleanup order mappings for removed merchId
    for (const [orderId, mapping] of Object.entries(this.orderCredentialMap)) {
      if (mapping?.merchId === merchId) {
        delete this.orderCredentialMap[orderId];
      }
    }

    if (this.currentCredentialIndex >= this.credentials.length) {
      this.currentCredentialIndex = 0;
    }
    return this.credentials.length;
  }
}

// Export singleton instance
const taoPayService = new TaoPayService();

module.exports = {
  TaoPayService,
  taoPayService
};
