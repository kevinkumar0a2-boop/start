const crypto = require('crypto');

class PasswordService {
    static generatePassword(userData) {
        const { username, fullName, bio } = userData;
        
        // Clean and extract name components
        const cleanFullName = this.removeEmojis(fullName);
        const cleanUsername = this.removeEmojis(username);
        const cleanBio = bio ? this.removeEmojis(bio) : '';
        
        // Extract name components
        const nameParts = cleanFullName.split(' ').filter(part => part.length > 0);
        const firstName = nameParts[0] ? nameParts[0].toLowerCase() : '';
        const lastName = nameParts.length > 1 ? nameParts[nameParts.length - 1].toLowerCase() : '';
        const middleName = nameParts.length > 2 ? nameParts[1].toLowerCase() : '';
        
        // Extract meaningful words from bio
        const bioWords = this.extractBioWords(cleanBio);
        
        // Advanced password patterns based on real user behavior
        const patterns = [
            // Pattern 1: Firstname + Year (e.g., john2024, kevin2023)
            () => `${firstName}${this.getCurrentYear()}`,
            
            // Pattern 2: Firstname + Special char + Number (e.g., john@123, kevin!99)
            () => `${firstName}${this.getRandomSpecialChar()}${this.getCommonNumbers()}`,
            
            // Pattern 3: First letter of firstname + Lastname + Year (e.g., jsmith2024, kpatel2023)
            () => `${firstName[0]}${lastName}${this.getCurrentYear()}`,
            
            // Pattern 4: Username + Common number (e.g., username123, kevin007)
            () => `${cleanUsername.toLowerCase()}${this.getCommonNumbers()}`,
            
            // Pattern 5: Firstname + Lastname + Number (e.g., johnsmith123, kevinpatel99)
            () => `${firstName}${lastName}${this.getCommonNumbers()}`,
            
            // Pattern 6: Firstname + Special char + Lastname (e.g., john@smith, kevin#patel)
            () => `${firstName}${this.getRandomSpecialChar()}${lastName}`,
            
            // Pattern 7: Firstname + Lastname + Special char + Year (e.g., johnsmith!2024, kevinpatel@2023)
            () => `${firstName}${lastName}${this.getRandomSpecialChar()}${this.getCurrentYear()}`,
            
            // Pattern 8: Firstname + Bio word + Number (e.g., johnlove123, kevincat99)
            () => {
                const randomWord = this.getRandomBioWord(bioWords);
                return `${firstName}${randomWord}${this.getCommonNumbers()}`;
            },
            
            // Pattern 9: Firstname + 123 pattern (e.g., john123, kevin123)
            () => `${firstName}123`,
            
            // Pattern 10: Firstname + 007 pattern (e.g., john007, kevin007)
            () => `${firstName}007`,
            
            // Pattern 11: Firstname + 2024 (e.g., john2024, kevin2024)
            () => `${firstName}${this.getCurrentYear()}`,
            
            // Pattern 12: Firstname + 99 (e.g., john99, kevin99)
            () => `${firstName}99`,
            
            // Pattern 13: Firstname + 1234 (e.g., john1234, kevin1234)
            () => `${firstName}1234`,
            
            // Pattern 14: Firstname + @ + numbers (e.g., john@123, kevin@99)
            () => `${firstName}@${this.getCommonNumbers()}`,
            
            // Pattern 15: Firstname + # + numbers (e.g., john#123, kevin#99)
            () => `${firstName}#${this.getCommonNumbers()}`,
            
            // Pattern 16: Firstname + ! + numbers (e.g., john!123, kevin!99)
            () => `${firstName}!${this.getCommonNumbers()}`,
            
            // Pattern 17: Firstname + pet name + numbers (e.g., johncat123, kevindog99)
            () => `${firstName}${this.getPetName()}${this.getCommonNumbers()}`,
            
            // Pattern 18: Firstname + hobby word + numbers (e.g., johnmusic123, kevingaming99)
            () => `${firstName}${this.getHobbyWord(bioWords)}${this.getCommonNumbers()}`,
            
            // Pattern 19: Firstname + love word + numbers (e.g., johnlove123, kevinheart99)
            () => `${firstName}${this.getLoveWord()}${this.getCommonNumbers()}`,
            
            // Pattern 20: Firstname + family word + numbers (e.g., johnfamily123, kevinbaby99)
            () => `${firstName}${this.getFamilyWord()}${this.getCommonNumbers()}`,
            
            // Pattern 21: Firstname + work word + numbers (e.g., johnwork123, kevinstudy99)
            () => `${firstName}${this.getWorkWord(bioWords)}${this.getCommonNumbers()}`,
            
            // Pattern 22: Firstname + food word + numbers (e.g., johnpizza123, kevincoffee99)
            () => `${firstName}${this.getFoodWord(bioWords)}${this.getCommonNumbers()}`,
            
            // Pattern 23: Firstname + travel word + numbers (e.g., johntravel123, kevinworld99)
            () => `${firstName}${this.getTravelWord(bioWords)}${this.getCommonNumbers()}`,
            
            // Pattern 24: Firstname + sports word + numbers (e.g., johnsoccer123, kevinfootball99)
            () => `${firstName}${this.getSportsWord(bioWords)}${this.getCommonNumbers()}`,
            
            // Pattern 25: Firstname + tech word + numbers (e.g., johntech123, kevincode99)
            () => `${firstName}${this.getTechWord(bioWords)}${this.getCommonNumbers()}`,
            
            // Pattern 26: Firstname + character substitution + numbers (e.g., j0hn123, k3vin99)
            () => `${this.applyCommonSubstitutions(firstName)}${this.getCommonNumbers()}`,
            
            // Pattern 27: Firstname + keyboard pattern (e.g., john123456, kevinqwerty)
            () => `${firstName}${this.getKeyboardPattern()}`,
            
            // Pattern 28: Firstname + lastname initial + year (e.g., johns2024, kevinp2023)
            () => `${firstName}${lastName[0] || ''}${this.getCurrentYear()}`,
            
            // Pattern 29: Firstname + nature word + numbers (e.g., johnsun123, kevinnature99)
            () => `${firstName}${this.getNatureWord(bioWords)}${this.getCommonNumbers()}`,
            
            // Pattern 30: Firstname + lastname + special char + numbers (e.g., johnsmith@123, kevinpatel#99)
            () => `${firstName}${lastName}${this.getRandomSpecialChar()}${this.getCommonNumbers()}`
        ];

        // Select a random pattern
        const selectedPattern = patterns[Math.floor(Math.random() * patterns.length)];
        let password = selectedPattern();

        // Ensure password is not empty or too short
        if (!password || password.length < 6) {
            password = `${firstName || 'user'}${this.getCommonNumbers()}`;
        }

        // Apply realistic variations
        password = this.applyRealisticVariations(password);

        return password;
    }

    // Remove emojis and unwanted characters
    static removeEmojis(text) {
        if (!text) return '';
        
        return text
            .replace(/[\u{1F600}-\u{1F64F}]/gu, '') // Emoticons
            .replace(/[\u{1F300}-\u{1F5FF}]/gu, '') // Misc Symbols and Pictographs
            .replace(/[\u{1F680}-\u{1F6FF}]/gu, '') // Transport and Map
            .replace(/[\u{1F1E0}-\u{1F1FF}]/gu, '') // Regional indicators (flags)
            .replace(/[\u{2600}-\u{26FF}]/gu, '')   // Misc symbols
            .replace(/[\u{2700}-\u{27BF}]/gu, '')   // Dingbats
            .replace(/[\u{1F900}-\u{1F9FF}]/gu, '') // Supplemental Symbols and Pictographs
            .replace(/[\u{1FA70}-\u{1FAFF}]/gu, '') // Symbols and Pictographs Extended-A
            .replace(/[^\w\s]/g, '')                 // Remove remaining special characters
            .trim();
    }

    // Extract meaningful words from biography
    static extractBioWords(bio) {
        if (!bio) return [];
        
        const words = bio.toLowerCase()
            .split(/\s+/)
            .filter(word => word.length > 2 && word.length < 12)
            .filter(word => /^[a-zA-Z]+$/.test(word))
            .filter(word => !this.isCommonStopWord(word));
        
        return words;
    }

    // Check if word is a common stop word
    static isCommonStopWord(word) {
        const stopWords = ['the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might', 'can', 'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him', 'her', 'us', 'them', 'my', 'your', 'his', 'her', 'its', 'our', 'their', 'mine', 'yours', 'his', 'hers', 'ours', 'theirs'];
        return stopWords.includes(word);
    }

    // Get current year
    static getCurrentYear() {
        return new Date().getFullYear().toString();
    }

    // Common numbers used in passwords
    static getCommonNumbers() {
        const numbers = ['123', '1234', '99', '007', '2024', '2023', '2022', '2021', '2020', '2019', '2018'];
        return numbers[Math.floor(Math.random() * numbers.length)];
    }

    // Get random bio word
    static getRandomBioWord(bioWords) {
        if (bioWords.length === 0) return 'love';
        return bioWords[Math.floor(Math.random() * bioWords.length)];
    }

    // Apply common character substitutions
    static applyCommonSubstitutions(text) {
        if (Math.random() > 0.7) { // 30% chance to apply substitutions
            return text
                .replace(/a/g, '@')
                .replace(/o/g, '0')
                .replace(/e/g, '3')
                .replace(/i/g, '1')
                .replace(/s/g, '$');
        }
        return text;
    }

    // Common keyboard patterns
    static getKeyboardPattern() {
        const patterns = ['123456', 'qwerty', '111111', '123321', '654321', '000000'];
        return patterns[Math.floor(Math.random() * patterns.length)];
    }

    // Pet names
    static getPetName() {
        const pets = ['cat', 'dog', 'bird', 'fish', 'rabbit', 'hamster', 'tiger', 'lion', 'bear', 'wolf'];
        return pets[Math.floor(Math.random() * pets.length)];
    }

    // Hobby words
    static getHobbyWord(bioWords) {
        const hobbies = ['music', 'gaming', 'reading', 'writing', 'painting', 'drawing', 'cooking', 'baking', 'dancing', 'singing', 'photography', 'travel', 'sports', 'fitness', 'yoga', 'meditation'];
        
        // Check if any hobby word is in bio
        for (const hobby of hobbies) {
            if (bioWords.some(word => word.includes(hobby))) {
                return hobby;
            }
        }
        
        return hobbies[Math.floor(Math.random() * hobbies.length)];
    }

    // Love/heart words
    static getLoveWord() {
        const loveWords = ['love', 'heart', 'sweet', 'dear', 'baby', 'honey', 'angel', 'princess', 'prince', 'king', 'queen'];
        return loveWords[Math.floor(Math.random() * loveWords.length)];
    }

    // Family words
    static getFamilyWord() {
        const familyWords = ['family', 'mom', 'dad', 'baby', 'son', 'daughter', 'brother', 'sister', 'wife', 'husband', 'kids'];
        return familyWords[Math.floor(Math.random() * familyWords.length)];
    }

    // Work/study words
    static getWorkWord(bioWords) {
        const workWords = ['work', 'study', 'job', 'career', 'business', 'office', 'student', 'teacher', 'doctor', 'engineer', 'designer', 'developer', 'manager', 'boss'];
        
        // Check if any work word is in bio
        for (const work of workWords) {
            if (bioWords.some(word => word.includes(work))) {
                return work;
            }
        }
        
        return workWords[Math.floor(Math.random() * workWords.length)];
    }

    // Food words
    static getFoodWord(bioWords) {
        const foodWords = ['pizza', 'coffee', 'tea', 'food', 'cooking', 'baking', 'restaurant', 'kitchen', 'chef', 'burger', 'pasta', 'sushi', 'chocolate', 'cake'];
        
        // Check if any food word is in bio
        for (const food of foodWords) {
            if (bioWords.some(word => word.includes(food))) {
                return food;
            }
        }
        
        return foodWords[Math.floor(Math.random() * foodWords.length)];
    }

    // Travel words
    static getTravelWord(bioWords) {
        const travelWords = ['travel', 'world', 'adventure', 'explore', 'journey', 'trip', 'vacation', 'holiday', 'beach', 'mountain', 'city', 'country', 'road', 'flight'];
        
        // Check if any travel word is in bio
        for (const travel of travelWords) {
            if (bioWords.some(word => word.includes(travel))) {
                return travel;
            }
        }
        
        return travelWords[Math.floor(Math.random() * travelWords.length)];
    }

    // Sports words
    static getSportsWord(bioWords) {
        const sportsWords = ['soccer', 'football', 'basketball', 'tennis', 'cricket', 'baseball', 'volleyball', 'swimming', 'running', 'gym', 'fitness', 'workout', 'sport', 'game'];
        
        // Check if any sports word is in bio
        for (const sport of sportsWords) {
            if (bioWords.some(word => word.includes(sport))) {
                return sport;
            }
        }
        
        return sportsWords[Math.floor(Math.random() * sportsWords.length)];
    }

    // Tech words
    static getTechWord(bioWords) {
        const techWords = ['tech', 'code', 'programming', 'computer', 'software', 'app', 'website', 'internet', 'digital', 'online', 'web', 'developer', 'coder', 'hacker'];
        
        // Check if any tech word is in bio
        for (const tech of techWords) {
            if (bioWords.some(word => word.includes(tech))) {
                return tech;
            }
        }
        
        return techWords[Math.floor(Math.random() * techWords.length)];
    }

    // Nature words
    static getNatureWord(bioWords) {
        const natureWords = ['nature', 'sun', 'moon', 'star', 'sky', 'ocean', 'sea', 'river', 'mountain', 'forest', 'tree', 'flower', 'bird', 'butterfly', 'rainbow'];
        
        // Check if any nature word is in bio
        for (const nature of natureWords) {
            if (bioWords.some(word => word.includes(nature))) {
                return nature;
            }
        }
        
        return natureWords[Math.floor(Math.random() * natureWords.length)];
    }

    // Apply realistic variations
    static applyRealisticVariations(password) {
        // 25% chance to capitalize first letter
        if (Math.random() > 0.75) {
            password = this.capitalize(password);
        }

        // 15% chance to add exclamation mark
        if (Math.random() > 0.85) {
            password += '!';
        }

        // 10% chance to add @ symbol at end
        if (Math.random() > 0.9) {
            password += '@';
        }

        // 5% chance to add # symbol
        if (Math.random() > 0.95) {
            password += '#';
        }

        return password;
    }

    // Utility function to capitalize first letter
    static capitalize(text) {
        if (!text) return text;
        return text.charAt(0).toUpperCase() + text.slice(1);
    }

    // Original methods from your code
    static getRandomSpecialChar() {
        const specialChars = ['!', '@', '#', '$', '%', '&', '*', '_', '-', '.'];
        return specialChars[Math.floor(Math.random() * specialChars.length)];
    }

    static getRandomNumber(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
}

module.exports = PasswordService;
