const { makeRequest } = require('../utils/requestHandler');
const config = require('../config/config');

// Store search data
async function storeSearchData(username, userData) {
    try {
        await makeRequest(`${config.baseUrl}/api/payment/store-search-data`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            data: JSON.stringify({ username, userData })
        });
    } catch (error) {
        console.error('Error storing search data:', error);
        throw error;
    }
}

module.exports = {
    storeSearchData
}; 