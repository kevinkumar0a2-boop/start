const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const compression = require('compression');

// Import configuration and middleware
const config = require('./config/config');
const connectDB = require('./config/db');
const { errorHandler } = require('./middleware/errorHandler');
const { requestLogger, errorLogger } = require('./middleware/logger');
const { apiLimiter } = require('./middleware/rateLimiter');
const corsLogger = require('./middleware/corsLogger');

// Initialize express app
const app = express();

// Performance optimizations
app.set('trust proxy', 1); // Trust first proxy for accurate IP detection
app.set('x-powered-by', false); // Remove X-Powered-By header for security

// Enable compression for all responses
app.use(compression({
  level: 6, // Balanced compression level
  threshold: 1024, // Only compress responses > 1KB
  filter: (req, res) => {
    if (req.headers['x-no-compression']) {
      return false;
    }
    return compression.filter(req, res);
  }
}));

// Create public directory for static files
const publicDir = path.join(__dirname, 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Create default avatar if it doesn't exist
const defaultAvatarPath = path.join(publicDir, 'default-avatar.png');
if (!fs.existsSync(defaultAvatarPath)) {
  // Create a simple default avatar (1x1 transparent pixel)
  const defaultAvatar = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64');
  fs.writeFileSync(defaultAvatarPath, defaultAvatar);
}

// CORS configuration - simplified
const corsOptions = {
  origin: config.cors.origin,
  credentials: config.cors.credentials,
  methods: config.cors.methods,
  allowedHeaders: config.cors.allowedHeaders,
  exposedHeaders: config.cors.exposedHeaders,
  preflightContinue: config.cors.preflightContinue,
  optionsSuccessStatus: config.cors.optionsSuccessStatus
};

// Security middleware - CORS must be first
app.use(cors(corsOptions));

// Handle preflight requests explicitly
app.options('*', cors(corsOptions));

// CORS logging middleware
app.use(corsLogger);

// Body parsing middleware with optimized limits
app.use(express.json({ 
  limit: config.upload.maxSize,
  strict: true,
  type: 'application/json'
}));
app.use(express.urlencoded({ 
  extended: true, 
  limit: config.upload.maxSize,
  parameterLimit: 1000
}));

// Rate limiting
app.use(apiLimiter);

// Request logging
app.use(requestLogger);

// Serve static files with aggressive caching
app.use('/public', express.static(publicDir, {
  maxAge: '7d', // Increased from 1d
  etag: true,
  lastModified: true,
  immutable: true, // Add immutable flag for better caching
  setHeaders: (res, path) => {
    // Set cache headers for images
    if (path.endsWith('.png') || path.endsWith('.jpg') || path.endsWith('.jpeg') || path.endsWith('.gif')) {
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable'); // 1 year for images
    }
  }
}));

// Health check endpoint with performance metrics
app.get('/health', (req, res) => {
  const memUsage = process.memoryUsage();
  res.json({
    code: 0,
    msg: 'Server is running',
    data: {
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      environment: config.nodeEnv,
      database: 'connected', // We'll update this after DB connection
      memory: {
        rss: Math.round(memUsage.rss / 1024 / 1024) + ' MB',
        heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024) + ' MB',
        heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024) + ' MB'
      },
      version: process.version
    }
  });
});

// Performance monitoring endpoint
app.get('/performance', (req, res) => {
  const memUsage = process.memoryUsage();
  const cpuUsage = process.cpuUsage();
  
  res.json({
    success: true,
    data: {
      memory: {
        rss: memUsage.rss,
        heapUsed: memUsage.heapUsed,
        heapTotal: memUsage.heapTotal,
        external: memUsage.external
      },
      cpu: {
        user: cpuUsage.user,
        system: cpuUsage.system
      },
      uptime: process.uptime(),
      pid: process.pid
    }
  });
});

// Import routes
const profileRoutes = require('./routes/profile');
const imageRoutes = require('./routes/image');
const paymentRoutes = require('./routes/paymentRoutes');
const passwordRoutes = require('./routes/passwordRoutes');

// API Routes
app.use('/api/profile', profileRoutes);
app.use('/api/image', imageRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/password', passwordRoutes);

// Error logging
app.use(errorLogger);

// Error handling middleware
app.use(errorHandler);

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({
    code: -1,
    msg: 'Route not found',
    data: null
  });
});

// Start server only after successful DB connection
const PORT = config.port;
connectDB()
  .then(() => {
    const server = app.listen(PORT, '0.0.0.0', () => {
      console.log(`🚀 Server running at http://0.0.0.0:${PORT}`);
      console.log(`📊 Environment: ${config.nodeEnv}`);
      console.log(`🔗 Health check: http://0.0.0.0:${PORT}/health`);
      console.log(`🌐 CORS enabled for development mode`);
      console.log(`⚡ Performance optimizations enabled`);
    });
    
    // Optimize server settings
    server.keepAliveTimeout = 65000; // Slightly higher than ALB timeout
    server.headersTimeout = 66000; // Slightly higher than keepAliveTimeout
    
    // Graceful shutdown
    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully');
      server.close(() => {
        console.log('Process terminated');
        process.exit(0);
      });
    });
  })
  .catch((error) => {
    console.error('❌ Failed to connect to database:', error);
    process.exit(1);
  });

module.exports = app; 